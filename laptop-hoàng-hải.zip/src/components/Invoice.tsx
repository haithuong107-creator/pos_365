import React from 'react';
import { Order } from '../types';
import { format } from 'date-fns';
import { generateInvoiceHtml } from '../utils/printInvoice';

interface InvoiceProps {
  order: Order;
  onClose: () => void;
  autoPrint?: boolean;
}

const Invoice: React.FC<InvoiceProps> = ({ order, onClose, autoPrint = false }) => {
  const handlePrint = () => {
    console.log('Invoice.tsx handlePrint manual click');
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Trình duyệt đã chặn cửa sổ in. Vui lòng cho phép bật lên.');
      return;
    }
    const invoiceHtml = generateInvoiceHtml(order);
    printWindow.document.write(invoiceHtml);
    printWindow.document.close();
  };

  React.useEffect(() => {
    if (autoPrint) {
      console.log('Invoice.tsx autoPrint triggered');
      handlePrint();
    }
  }, [autoPrint]);

  return (
    <div className="fixed inset-0 bg-black/50 z-[110] flex items-center justify-center overflow-y-auto p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full flex flex-col max-h-[95vh] relative">
        {/* Sticky Header */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-20 rounded-t-2xl no-print">
          <div className="flex items-center gap-4">
            <h2 className="text-2xl font-bold text-slate-900">Xem trước hoá đơn A4</h2>
            <span className="px-3 py-1 bg-slate-100 text-slate-600 text-xs font-bold rounded-full uppercase tracking-wider">Khổ ngang (Landscape)</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
              In hoá đơn
            </button>
            <button 
              onClick={onClose}
              className="p-2.5 hover:bg-slate-100 rounded-xl transition-colors text-slate-400 hover:text-slate-600"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 bg-slate-50">
          {/* Invoice Content */}
          <div id="invoice-content" className="bg-white border border-slate-200 shadow-xl mx-auto w-full max-w-[297mm] h-[210mm] flex relative overflow-hidden print:p-0 print:border-0 print:shadow-none print:w-[297mm] print:h-[210mm]">
            
            {/* LEFT HALF: PHIẾU XUẤT KHO */}
            <div className="w-1/2 border-r-2 border-slate-300 p-6 relative flex flex-col h-full overflow-hidden">
              {/* Watermark */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] rotate-[-25deg] z-0">
                <span className="text-red-600 text-5xl font-bold whitespace-nowrap uppercase tracking-widest">
                  MÁY TÍNH HOÀNG HẢI
                </span>
              </div>

              {/* Header */}
              <div className="flex gap-4 mb-4 relative z-10">
                <div className="w-20 h-20 flex-shrink-0">
                  <img 
                    src="https://firebasestorage.googleapis.com/v0/b/hoang-hai-empire.appspot.com/o/logo-red.png?alt=media" 
                    alt="Hoang Hai Logo" 
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://picsum.photos/seed/computer/200/200";
                    }}
                  />
                </div>
                <div className="flex-1 text-center">
                  <h1 className="text-xl font-black text-red-600 uppercase mb-0.5 tracking-tighter">MÁY TÍNH HOÀNG HẢI</h1>
                  <p className="text-red-600 font-bold text-[10px] mb-0.5">PHÂN PHỐI LAPTOP NHẬT - MỸ - TRUNG QUỐC</p>
                  <p className="text-red-600 text-[9px] font-medium">📍 SỐ 6/107 CHI LĂNG - NGUYỄN TRÃI - TP HẢI DƯƠNG</p>
                  <div className="flex justify-center items-center gap-4 text-red-600 text-sm font-black mt-0.5">
                    <span className="flex items-center gap-1">📞 0934.393.404</span>
                    <span className="flex items-center gap-1">💬 0934.393.404</span>
                  </div>
                </div>
              </div>

              <div className="text-center mb-4 relative z-10">
                <h2 className="text-lg font-black text-red-600 uppercase tracking-widest border-t border-b border-red-600 py-1 inline-block px-4">
                  PHIẾU XUẤT KHO - KIÊM BẢO HÀNH
                </h2>
              </div>

              {/* Customer Info */}
              <div className="space-y-2 mb-4 text-[11px] relative z-10">
                <div className="flex justify-between border-b border-red-600 border-dotted pb-0.5">
                  <div className="flex gap-2 flex-1">
                    <span className="font-bold text-red-600 whitespace-nowrap">Khách hàng:</span>
                    <span className="uppercase font-bold">{order.customerName || '................................................................................'}</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="font-bold text-red-600 whitespace-nowrap">Số phiếu:</span>
                    <span className="font-bold">{order.id.slice(-6).toUpperCase() || '................'}</span>
                  </div>
                </div>
                <div className="flex gap-2 border-b border-red-600 border-dotted pb-0.5">
                  <span className="font-bold text-red-600 whitespace-nowrap">Địa chỉ:</span>
                  <span className="truncate">{order.shippingAddress || '................................................................................................................................'}</span>
                </div>
              </div>

              {/* Table */}
              <table className="w-full border-collapse border border-red-600 mb-4 relative z-10 text-[10px]">
                <thead>
                  <tr className="bg-red-50">
                    <th className="border border-red-600 py-1 px-0.5 text-red-600 font-black w-8">TT</th>
                    <th className="border border-red-600 py-1 px-1 text-red-600 font-black">Hàng hóa</th>
                    <th className="border border-red-600 py-1 px-0.5 text-red-600 font-black w-12">ĐVT</th>
                    <th className="border border-red-600 py-1 px-0.5 text-red-600 font-black w-10">SL</th>
                    <th className="border border-red-600 py-1 px-1 text-red-600 font-black w-20">Đơn Giá</th>
                    <th className="border border-red-600 py-1 px-1 text-red-600 font-black w-24">Thành Tiền</th>
                  </tr>
                </thead>
                <tbody>
                  {order.items.map((item, index) => (
                    <tr key={index} className="h-7">
                      <td className="border border-red-600 text-center font-bold text-red-600">{index + 1}</td>
                      <td className="border border-red-600 px-1 font-bold truncate max-w-[150px]">{item.name}</td>
                      <td className="border border-red-600 text-center">Cái</td>
                      <td className="border border-red-600 text-center font-bold">{item.quantity}</td>
                      <td className="border border-red-600 text-right px-1 font-bold">{item.price.toLocaleString()}</td>
                      <td className="border border-red-600 text-right px-1 font-bold">{(item.price * item.quantity).toLocaleString()}</td>
                    </tr>
                  ))}
                  {Array.from({ length: Math.max(0, 8 - order.items.length) }).map((_, i) => (
                    <tr key={`empty-${i}`} className="h-7">
                      <td className="border border-red-600 text-center font-bold text-red-600">{order.items.length + i + 1}</td>
                      <td className="border border-red-600 px-1"></td>
                      <td className="border border-red-600 text-center"></td>
                      <td className="border border-red-600 text-center"></td>
                      <td className="border border-red-600 text-right px-1"></td>
                      <td className="border border-red-600 text-right px-1"></td>
                    </tr>
                  ))}
                  <tr className="h-8 bg-red-50">
                    <td colSpan={5} className="border border-red-600 text-center text-sm font-black text-red-600 uppercase tracking-widest">Tổng</td>
                    <td className="border border-red-600 text-right px-1 text-sm font-black text-red-600">
                      {(order.finalAmount || order.totalAmount).toLocaleString()}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Payment Info */}
              <div className="flex justify-center mb-4 relative z-10">
                <div className="border border-red-600 p-2 rounded-lg text-center min-w-[250px]">
                  <h3 className="text-red-600 font-black text-sm mb-0.5 uppercase tracking-tight">Thông tin chuyển khoản</h3>
                  <p className="text-red-600 font-black text-xs italic mb-0.5">Phạm Quỳnh Hải</p>
                  <p className="text-red-600 font-black text-sm mb-0.5 tracking-widest">1983.886.99999</p>
                  <p className="text-red-600 font-black text-xs italic">Ngân hàng Quân Đội</p>
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-between items-start mb-8 relative z-10 text-[11px]">
                <div className="text-center">
                  <p className="font-black text-red-600 mb-0.5">Người mua hàng</p>
                  <p className="text-[9px] italic text-red-600">(Ký, ghi rõ họ tên)</p>
                </div>
                <div className="text-center">
                  <p className="text-[9px] italic text-red-600 mb-1">Ngày ...... tháng ...... năm 20.....</p>
                  <p className="font-black text-red-600 mb-0.5">Người bán hàng</p>
                  <p className="text-[9px] italic text-red-600">(Ký, ghi rõ họ tên)</p>
                </div>
              </div>

              <div className="text-center relative z-10 mt-auto">
                <p className="text-red-600 font-black italic text-[11px] tracking-tight">
                  Cám ơn quý khách đã sử dụng dịch vụ của Máy tính Hoàng Hải !
                </p>
              </div>
            </div>

            {/* RIGHT HALF: PHIẾU GỬI HÀNG */}
            <div className="w-1/2 p-6 flex flex-col gap-6 h-full overflow-hidden">
              {[1, 2].map((i) => (
                <div key={i} className={`flex-1 flex flex-col ${i === 1 ? 'border-b-2 border-slate-300 pb-6' : 'pt-2'}`}>
                  {/* Store Header */}
                  <div className="flex gap-4 mb-4">
                    <div className="w-16 h-16 flex-shrink-0">
                      <img 
                        src="https://firebasestorage.googleapis.com/v0/b/hoang-hai-empire.appspot.com/o/logo-red.png?alt=media" 
                        alt="Hoang Hai Logo" 
                        className="w-full h-full object-contain"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://picsum.photos/seed/computer/200/200";
                        }}
                      />
                    </div>
                    <div className="flex-1">
                      <h1 className="text-lg font-black text-red-600 uppercase leading-none mb-1">MÁY TÍNH HOÀNG HẢI</h1>
                      <p className="text-red-600 font-bold text-[9px] mb-0.5">PHÂN PHỐI LAPTOP NHẬT - MỸ - TRUNG QUỐC</p>
                      <p className="text-red-600 text-[8px] font-medium mb-0.5">📍 SỐ 6/107 CHI LĂNG - NGUYỄN TRÃI - TP HẢI DƯƠNG</p>
                      <div className="flex items-center gap-4 text-red-600 text-xs font-black">
                        <span className="flex items-center gap-1">📞 0934.393.404</span>
                        <span className="flex items-center gap-1">💬 0934.393.404</span>
                      </div>
                    </div>
                  </div>

                  <div className="h-0.5 bg-green-600 w-full mb-4"></div>

                  {/* Shipping Fields */}
                  <div className="space-y-4 flex-1">
                    <div className="flex items-start gap-2">
                      <span className="text-red-600 font-black text-xl uppercase whitespace-nowrap mt-1">NGƯỜI NHẬN:</span>
                      <div className="flex-1 border-b border-blue-400 min-h-[32px] text-xl font-bold uppercase pt-1">
                        {order.customerName}
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-red-600 font-black text-xl uppercase whitespace-nowrap mt-1">ĐỊA CHỈ:</span>
                      <div className="flex-1 space-y-4">
                        <div className="border-b border-blue-400 min-h-[32px] text-lg font-bold pt-1 leading-tight">
                          {order.shippingAddress}
                        </div>
                        <div className="border-b border-blue-400 min-h-[32px]"></div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="text-red-600 font-black text-xl uppercase whitespace-nowrap mt-1">ĐIỆN THOẠI:</span>
                      <div className="flex-1 border-b border-blue-400 min-h-[32px] text-2xl font-black tracking-widest pt-1">
                        {order.customerPhone}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sticky Footer */}
        <div className="p-4 border-t border-slate-100 flex items-center justify-center bg-white z-20 rounded-b-2xl sticky bottom-0 no-print">
          <button 
            onClick={handlePrint}
            className="flex items-center gap-2 px-12 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20 active:scale-95"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
            In hoá đơn ngay
          </button>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          @page {
            size: A4 landscape;
            margin: 0;
          }
          html, body {
            height: 100%;
            margin: 0 !important;
            padding: 0 !important;
            overflow: hidden !important;
          }
          body * {
            visibility: hidden !important;
          }
          #invoice-content, #invoice-content * {
            visibility: visible !important;
          }
          #invoice-content {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 297mm !important;
            height: 210mm !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            display: flex !important;
            z-index: 9999 !important;
          }
          .no-print {
            display: none !important;
          }
        }
      `}} />
    </div>
  );
};

export default Invoice;
