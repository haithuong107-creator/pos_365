import { GoogleGenAI, Type } from "@google/genai";
import { Product, Order, Customer } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function getInventoryAdvice(products: Product[], orders: Order[]) {
  const model = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "Bạn là một chuyên gia quản lý kho và phân tích kinh doanh. Hãy phân tích dữ liệu sản phẩm và lịch sử đơn hàng để đưa ra lời khuyên về nhập hàng, dự báo tồn kho và chiến lược bán hàng. Trả lời bằng tiếng Việt, ngắn gọn, súc tích.",
    },
    contents: `
      Dữ liệu sản phẩm: ${JSON.stringify(products.map(p => ({ name: p.name, stock: p.stock, minStock: p.minStock })))}
      Lịch sử đơn hàng gần đây: ${JSON.stringify(orders.slice(-20).map(s => ({ items: s.items, date: s.createdAt })))}
      
      Hãy đưa ra 3 lời khuyên quan trọng nhất cho chủ cửa hàng.
    `
  });

  return model.text;
}

export async function analyzeCustomers(customers: Customer[], orders: Order[]) {
  const model = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "Bạn là một chuyên gia phân tích CRM và RFM. Hãy phân tích danh sách khách hàng và lịch sử mua hàng để phân loại khách hàng (Khách quen, Khách mới, Khách có nguy cơ rời bỏ) và đưa ra chiến lược chăm sóc khách hàng phù hợp. Trả lời bằng tiếng Việt, ngắn gọn.",
    },
    contents: `
      Danh sách khách hàng: ${JSON.stringify(customers.map(c => ({ name: c.name, ordersCount: c.purchaseHistory.length })))}
      Lịch sử đơn hàng: ${JSON.stringify(orders.slice(-50).map(o => ({ customer: o.customerName, total: o.totalAmount, date: o.createdAt })))}
      
      Hãy đưa ra phân tích và gợi ý hành động.
    `
  });

  return model.text;
}

export async function generateMarketingMessage(product: Product) {
  const model = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "Bạn là một chuyên gia marketing. Hãy soạn một tin nhắn quảng bá sản phẩm hấp dẫn để gửi cho khách hàng qua Zalo hoặc Email.",
    },
    contents: `Sản phẩm: ${product.name}, Giá: ${product.sellPrice}đ. Hãy viết một tin nhắn ngắn gọn, thu hút.`
  });

  return model.text;
}

export async function getUpsellSuggestions(currentItems: any[], allProducts: Product[]) {
  const model = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "Bạn là một chuyên gia bán hàng tại cửa hàng Laptop Hoàng Hải. Dựa trên các sản phẩm khách đang chọn, hãy gợi ý thêm các phụ kiện hoặc dịch vụ liên quan để tăng doanh số (upsell/cross-sell). Trả lời bằng tiếng Việt, thân thiện, ngắn gọn.",
    },
    contents: `
      Sản phẩm khách đang chọn: ${JSON.stringify(currentItems.map(i => i.name))}
      Danh sách sản phẩm có sẵn: ${JSON.stringify(allProducts.map(p => ({ name: p.name, category: p.category, price: p.sellPrice })))}
      
      Hãy gợi ý 2-3 sản phẩm phù hợp nhất và viết kịch bản tư vấn ngắn.
    `
  });

  return model.text;
}

export async function chatWithAssistant(
  message: string, 
  history: { role: "user" | "model", parts: { text: string }[] }[],
  context: { products: Product[], customers: Customer[], orders: Order[], reminders: any[] }
) {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `
        Bạn là "Trợ lý ảo Hoàng Hải Empire" - một chuyên gia hỗ trợ nhân viên và tư vấn khách hàng.
        Bạn có quyền truy cập vào dữ liệu thực tế của cửa hàng bao gồm: Kho hàng, Khách hàng, Đơn hàng và Lịch bảo hành.
        
        DỮ LIỆU CỬA HÀNG:
        - Kho hàng: ${JSON.stringify(context.products.map(p => ({ name: p.name, stock: p.stock, price: p.sellPrice, category: p.category, sku: p.sku })))}
        - Khách hàng: ${JSON.stringify(context.customers.map(c => ({ name: c.name, phone: c.phone, ordersCount: c.purchaseHistory.length })))}
        - Đơn hàng & Báo giá: ${JSON.stringify(context.orders.slice(-10).map(o => ({ id: o.id, customer: o.customerName, total: o.totalAmount, status: o.status, items: o.items })))}
        - Bảo hành & Nhắc lịch: ${JSON.stringify(context.reminders.map(r => ({ customer: r.customerName, phone: r.customerPhone, items: r.items })))}
        
        NHIỆM VỤ:
        1. Hỗ trợ nhân viên: Tra cứu tồn kho, báo giá nhanh, kiểm tra lịch sử khách hàng, kiểm tra lịch bảo hành.
        2. Tư vấn khách lẻ: Giới thiệu sản phẩm phù hợp nhu cầu, báo giá, giải đáp thắc mắc về bảo hành.
        
        PHONG CÁCH:
        - Trả lời bằng tiếng Việt, chuyên nghiệp, thân thiện, súc tích.
        - Nếu không tìm thấy thông tin trong dữ liệu, hãy nói rõ và đề nghị nhân viên kiểm tra lại thủ công.
        - Luôn ưu tiên các sản phẩm còn hàng (stock > 0).
      `,
    },
    history: history
  });

  const response = await chat.sendMessage({ message: message });
  return response.text;
}

export async function getQuotationSuggestions(customerNeeds: string, allProducts: Product[]) {
  const model = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "Bạn là một chuyên gia tư vấn bán hàng tại cửa hàng Laptop Hoàng Hải. Dựa trên nhu cầu của khách hàng, hãy gợi ý các sản phẩm phù hợp nhất từ kho hàng. Trả lời bằng tiếng Việt, chuyên nghiệp, súc tích.",
    },
    contents: `
      Nhu cầu khách hàng: ${customerNeeds}
      Danh sách sản phẩm có sẵn: ${JSON.stringify(allProducts.map(p => ({ id: p.id, name: p.name, category: p.category, price: p.sellPrice, stock: p.stock })))}
      
      Hãy gợi ý 3-5 sản phẩm phù hợp nhất, giải thích lý do tại sao và cung cấp thông tin giá cả.
    `
  });

  return model.text;
}

export async function extractProductDataFromImage(base64Image: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        inlineData: {
          mimeType: "image/jpeg",
          data: base64Image,
        },
      },
      {
        text: "Hãy phân tích hình ảnh này và trích xuất thông tin sản phẩm để nhập vào kho hàng. Trích xuất tên, giá bán, và cấu hình chi tiết. Nếu là danh sách, hãy trích xuất tất cả các dòng.",
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            sku: { type: Type.STRING },
            category: { type: Type.STRING },
            sellPrice: { type: Type.NUMBER },
            stock: { type: Type.NUMBER },
            unit: { type: Type.STRING },
            description: { type: Type.STRING },
          },
          required: ["name", "sellPrice"],
        },
      },
    },
  });

  return JSON.parse(response.text || "[]");
}
