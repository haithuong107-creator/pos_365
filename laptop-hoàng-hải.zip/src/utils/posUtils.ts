import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Order, OrderItem } from '../types';

export const generateVietQRUrl = (amount: number, description: string) => {
  // VietQR Format: https://img.vietqr.io/image/<BANK_ID>-<ACCOUNT_NO>-<TEMPLATE>.png?amount=<AMOUNT>&addInfo=<DESCRIPTION>&accountName=<ACCOUNT_NAME>
  const BANK_ID = 'MB'; // Example: MB Bank
  const ACCOUNT_NO = '1234567890'; // Replace with real account
  const ACCOUNT_NAME = 'LAPTOP HOANG HAI';
  const TEMPLATE = 'compact';
  
  const encodedDesc = encodeURIComponent(description);
  const encodedName = encodeURIComponent(ACCOUNT_NAME);
  
  return `https://img.vietqr.io/image/${BANK_ID}-${ACCOUNT_NO}-${TEMPLATE}.png?amount=${amount}&addInfo=${encodedDesc}&accountName=${encodedName}`;
};

export const downloadInvoicePDF = (order: Order) => {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(20);
  doc.text('LAPTOP HOÀNG HẢI', 105, 20, { align: 'center' });
  doc.setFontSize(10);
  doc.text('Địa chỉ: Số 10 Ngân Sơn, TP. Bắc Kạn', 105, 28, { align: 'center' });
  doc.text('Hotline: 0987.654.321', 105, 33, { align: 'center' });
  
  doc.line(20, 40, 190, 40);
  
  // Order Info
  doc.setFontSize(14);
  doc.text(`HÓA ĐƠN BÁN HÀNG`, 105, 50, { align: 'center' });
  doc.setFontSize(10);
  doc.text(`Mã đơn: ${order.id}`, 20, 60);
  doc.text(`Ngày: ${new Date(order.createdAt).toLocaleString('vi-VN')}`, 20, 65);
  doc.text(`Khách hàng: ${order.customerName || 'Khách lẻ'}`, 20, 70);
  doc.text(`SĐT: ${order.customerPhone || 'N/A'}`, 20, 75);
  
  // Table
  const tableData = order.items.map((item: OrderItem, index: number) => [
    index + 1,
    item.name,
    item.quantity,
    item.price.toLocaleString() + 'đ',
    (item.price * item.quantity).toLocaleString() + 'đ'
  ]);
  
  autoTable(doc, {
    startY: 85,
    head: [['STT', 'Tên sản phẩm', 'SL', 'Đơn giá', 'Thành tiền']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42] },
  });
  
  const finalY = (doc as any).lastAutoTable.finalY + 10;
  
  // Totals
  doc.text(`Tổng cộng: ${order.totalAmount.toLocaleString()}đ`, 140, finalY);
  doc.text(`VAT: ${order.vatAmount.toLocaleString()}đ`, 140, finalY + 5);
  doc.text(`Giảm giá: ${order.discount.toLocaleString()}đ`, 140, finalY + 10);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`THANH TOÁN: ${order.finalAmount.toLocaleString()}đ`, 140, finalY + 18);
  
  // Footer
  doc.setFontSize(10);
  doc.setFont('helvetica', 'italic');
  doc.text('Cảm ơn quý khách đã tin tưởng Laptop Hoàng Hải!', 105, finalY + 35, { align: 'center' });
  
  doc.save(`HoaDon_${order.id}.pdf`);
};

export const sendZaloNotification = (phone: string, message: string) => {
  // Zalo deep link format: https://zalo.me/<phone>
  // Note: For Zalo OA, we would use an API, but for personal Zalo, we open the chat.
  const cleanPhone = phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  const url = `https://zalo.me/${cleanPhone}`;
  
  // We can't pass the message directly in the URL for personal Zalo, 
  // but we can copy it to clipboard or just open the chat.
  // For a real integration, we'd use Zalo OA API.
  window.open(url, '_blank');
  
  // Optional: Copy message to clipboard for easy pasting
  navigator.clipboard.writeText(message).then(() => {
    console.log('Message copied to clipboard');
  });
};

export const sendSMSNotification = (phone: string, message: string) => {
  const cleanPhone = phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  const url = `sms:${cleanPhone}?body=${encodedMessage}`;
  window.location.href = url;
};

export const getOrderNotificationMessage = (order: Order, type: 'status' | 'delivery') => {
  const storeName = 'Laptop Hoàng Hải';
  const orderId = order.id.slice(-6).toUpperCase();
  const total = order.finalAmount.toLocaleString();
  
  if (type === 'status') {
    return `Chào bạn, đơn hàng #${orderId} tại ${storeName} đã được cập nhật trạng thái: ${order.status}. Tổng thanh toán: ${total}đ. Cảm ơn bạn!`;
  } else {
    return `Chào bạn, đơn hàng #${orderId} tại ${storeName} đang được giao đến địa chỉ của bạn. Vui lòng giữ liên lạc để nhận hàng. Trân trọng!`;
  }
};
