import { Order } from '../types';

export const generateInvoiceHtml = (order: Order) => {
  const itemsHtml = order.items.map((item, index) => `
    <tr style="height: 28px;">
      <td style="border: 1px solid #dc2626; text-align: center; font-weight: bold; color: #dc2626;">${index + 1}</td>
      <td style="border: 1px solid #dc2626; padding: 0 4px; font-weight: bold; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;">${item.name}</td>
      <td style="border: 1px solid #dc2626; text-align: center;">Cái</td>
      <td style="border: 1px solid #dc2626; text-align: center; font-weight: bold;">${item.quantity}</td>
      <td style="border: 1px solid #dc2626; text-align: right; padding: 0 4px; font-weight: bold;">${item.price.toLocaleString()}</td>
      <td style="border: 1px solid #dc2626; text-align: right; padding: 0 4px; font-weight: bold;">${(item.price * item.quantity).toLocaleString()}</td>
    </tr>
  `).join('');

  const emptyRowsCount = Math.max(0, 8 - order.items.length);
  const emptyRowsHtml = Array.from({ length: emptyRowsCount }).map((_, i) => `
    <tr style="height: 28px;">
      <td style="border: 1px solid #dc2626; text-align: center; font-weight: bold; color: #dc2626;">${order.items.length + i + 1}</td>
      <td style="border: 1px solid #dc2626;"></td>
      <td style="border: 1px solid #dc2626;"></td>
      <td style="border: 1px solid #dc2626;"></td>
      <td style="border: 1px solid #dc2626;"></td>
      <td style="border: 1px solid #dc2626;"></td>
    </tr>
  `).join('');

  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>In Hóa Đơn - ${order.id}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap');
          @page { size: A4 landscape; margin: 0; }
          body { font-family: 'Roboto', sans-serif; margin: 0; padding: 0; color: #000; background: #fff; }
          .container { width: 297mm; height: 210mm; display: flex; overflow: hidden; }
          .left { width: 50%; border-right: 2px solid #cbd5e1; padding: 24px; box-sizing: border-box; display: flex; flex-direction: column; position: relative; }
          .right { width: 50%; padding: 24px; box-sizing: border-box; display: flex; flex-direction: column; gap: 24px; }
          .watermark { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; opacity: 0.03; transform: rotate(-25deg); pointer-events: none; z-index: 0; font-size: 48px; font-weight: 900; color: #dc2626; text-transform: uppercase; white-space: nowrap; }
          .header { display: flex; gap: 16px; margin-bottom: 16px; position: relative; z-index: 10; }
          .logo { width: 80px; height: 80px; object-fit: contain; }
          .biz-info { flex: 1; text-align: center; }
          .biz-name { font-size: 20px; font-weight: 900; color: #dc2626; text-transform: uppercase; margin: 0 0 2px 0; letter-spacing: -0.5px; }
          .biz-sub { color: #dc2626; font-weight: 700; font-size: 10px; margin: 0 0 2px 0; }
          .biz-addr { color: #dc2626; font-size: 9px; font-weight: 500; margin: 0; }
          .biz-contact { display: flex; justify-content: center; gap: 16px; color: #dc2626; font-size: 14px; font-weight: 900; margin-top: 2px; }
          .title-box { text-align: center; margin-bottom: 16px; position: relative; z-index: 10; }
          .title { font-size: 18px; font-weight: 900; color: #dc2626; text-transform: uppercase; border-top: 1px solid #dc2626; border-bottom: 1px solid #dc2626; padding: 4px 16px; display: inline-block; }
          .cust-info { font-size: 11px; margin-bottom: 16px; position: relative; z-index: 10; }
          .info-row { display: flex; justify-content: space-between; border-bottom: 1px dotted #dc2626; padding-bottom: 2px; margin-bottom: 8px; }
          .label { font-weight: 700; color: #dc2626; margin-right: 8px; }
          .val { font-weight: 700; text-transform: uppercase; }
          table { width: 100%; border-collapse: collapse; border: 1px solid #dc2626; font-size: 10px; margin-bottom: 16px; position: relative; z-index: 10; }
          th { background: #fef2f2; border: 1px solid #dc2626; padding: 4px; color: #dc2626; font-weight: 900; }
          .total-row { background: #fef2f2; height: 32px; }
          .total-label { border: 1px solid #dc2626; text-align: center; font-size: 14px; font-weight: 900; color: #dc2626; text-transform: uppercase; }
          .total-val { border: 1px solid #dc2626; text-align: right; padding: 0 4px; font-size: 14px; font-weight: 900; color: #dc2626; }
          .bank-box { border: 1px solid #dc2626; padding: 8px; border-radius: 8px; text-align: center; margin: 0 auto 16px auto; min-width: 250px; position: relative; z-index: 10; }
          .bank-title { color: #dc2626; font-weight: 900; font-size: 14px; margin: 0 0 2px 0; text-transform: uppercase; }
          .bank-name { color: #dc2626; font-weight: 900; font-size: 12px; font-style: italic; margin: 0 0 2px 0; }
          .bank-acc { color: #dc2626; font-weight: 900; font-size: 14px; margin: 0 0 2px 0; letter-spacing: 2px; }
          .bank-sub { color: #dc2626; font-weight: 900; font-size: 12px; font-style: italic; margin: 0; }
          .signatures { display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 32px; position: relative; z-index: 10; }
          .sig-box { text-align: center; }
          .sig-label { font-weight: 900; color: #dc2626; margin-bottom: 2px; }
          .sig-sub { font-size: 9px; font-style: italic; color: #dc2626; }
          .footer-msg { text-align: center; color: #dc2626; font-weight: 900; font-style: italic; font-size: 11px; margin-top: auto; position: relative; z-index: 10; }
          .ship-label { color: #dc2626; font-weight: 900; font-size: 20px; text-transform: uppercase; margin-top: 4px; }
          .ship-val { flex: 1; border-bottom: 1px solid #60a5fa; min-height: 32px; font-size: 20px; font-weight: 700; text-transform: uppercase; padding-top: 4px; }
          .ship-val-lg { font-size: 24px; font-weight: 900; letter-spacing: 2px; }
          .green-line { height: 2px; background: #16a34a; width: 100%; margin-bottom: 16px; }
        </style>
      </head>
      <body>
        <div class="container">
          <!-- PHIẾU XUẤT KHO -->
          <div class="left">
            <div class="watermark">MÁY TÍNH HOÀNG HẢI</div>
            <div class="header">
              <img src="https://firebasestorage.googleapis.com/v0/b/hoang-hai-empire.appspot.com/o/logo-red.png?alt=media" class="logo" onerror="this.src='https://picsum.photos/seed/computer/200/200'">
              <div class="biz-info">
                <h1 class="biz-name">MÁY TÍNH HOÀNG HẢI</h1>
                <p class="biz-sub">PHÂN PHỐI LAPTOP NHẬT - MỸ - TRUNG QUỐC</p>
                <p class="biz-addr">📍 SỐ 6/107 CHI LĂNG - NGUYỄN TRÃI - TP HẢI DƯƠNG</p>
                <div class="biz-contact">
                  <span>📞 0934.393.404</span>
                  <span>💬 0934.393.404</span>
                </div>
              </div>
            </div>
            <div class="title-box">
              <h2 class="title">PHIẾU XUẤT KHO - KIÊM BẢO HÀNH</h2>
            </div>
            <div class="cust-info">
              <div class="info-row">
                <div style="display: flex; flex: 1;">
                  <span class="label">Khách hàng:</span>
                  <span class="val">${order.customerName || '................................................................................'}</span>
                </div>
                <div>
                  <span class="label">Số phiếu:</span>
                  <span class="val">${order.id.slice(-6).toUpperCase()}</span>
                </div>
              </div>
              <div class="info-row">
                <span class="label">Địa chỉ:</span>
                <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${order.shippingAddress || '................................................................................................................................'}</span>
              </div>
            </div>
            <table>
              <thead>
                <tr>
                  <th style="width: 32px;">TT</th>
                  <th>Hàng hóa</th>
                  <th style="width: 48px;">ĐVT</th>
                  <th style="width: 40px;">SL</th>
                  <th style="width: 80px;">Đơn Giá</th>
                  <th style="width: 96px;">Thành Tiền</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHtml}
                ${emptyRowsHtml}
                <tr class="total-row">
                  <td colspan="5" class="total-label">Tổng</td>
                  <td class="total-val">${(order.finalAmount || order.totalAmount).toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
            <div class="bank-box">
              <h3 class="bank-title">Thông tin chuyển khoản</h3>
              <p class="bank-name">Phạm Quỳnh Hải</p>
              <p class="bank-acc">1983.886.99999</p>
              <p class="bank-sub">Ngân hàng Quân Đội</p>
            </div>
            <div class="signatures">
              <div class="sig-box">
                <p class="sig-label">Người mua hàng</p>
                <p class="sig-sub">(Ký, ghi rõ họ tên)</p>
              </div>
              <div class="sig-box">
                <p class="sig-sub" style="margin-bottom: 4px;">Ngày ...... tháng ...... năm 20.....</p>
                <p class="sig-label">Người bán hàng</p>
                <p class="sig-sub">(Ký, ghi rõ họ tên)</p>
              </div>
            </div>
            <p class="footer-msg">Cám ơn quý khách đã sử dụng dịch vụ của Máy tính Hoàng Hải !</p>
          </div>

          <!-- PHIẾU GỬI HÀNG -->
          <div class="right">
            ${[1, 2].map(i => `
              <div style="flex: 1; display: flex; flex-direction: column; ${i === 1 ? 'border-bottom: 2px solid #cbd5e1; padding-bottom: 24px;' : 'padding-top: 8px;'}">
                <div class="header" style="margin-bottom: 8px;">
                  <img src="https://firebasestorage.googleapis.com/v0/b/hoang-hai-empire.appspot.com/o/logo-red.png?alt=media" style="width: 64px; height: 64px; object-fit: contain;" onerror="this.src='https://picsum.photos/seed/computer/200/200'">
                  <div style="flex: 1;">
                    <h1 style="font-size: 18px; font-weight: 900; color: #dc2626; text-transform: uppercase; margin: 0 0 4px 0;">MÁY TÍNH HOÀNG HẢI</h1>
                    <p style="color: #dc2626; font-weight: 700; font-size: 9px; margin: 0 0 2px 0;">PHÂN PHỐI LAPTOP NHẬT - MỸ - TRUNG QUỐC</p>
                    <p style="color: #dc2626; font-size: 8px; font-weight: 500; margin: 0 0 2px 0;">📍 SỐ 6/107 CHI LĂNG - NGUYỄN TRÃI - TP HẢI DƯƠNG</p>
                    <div style="display: flex; gap: 16px; color: #dc2626; font-size: 12px; font-weight: 900;">
                      <span>📞 0934.393.404</span>
                      <span>💬 0934.393.404</span>
                    </div>
                  </div>
                </div>
                <div class="green-line"></div>
                <div style="display: flex; flex-direction: column; gap: 16px; flex: 1;">
                  <div style="display: flex; align-items: flex-start; gap: 8px;">
                    <span class="ship-label">NGƯỜI NHẬN:</span>
                    <div class="ship-val">${order.customerName || ''}</div>
                  </div>
                  <div style="display: flex; align-items: flex-start; gap: 8px;">
                    <span class="ship-label">ĐỊA CHỈ:</span>
                    <div style="flex: 1; display: flex; flex-direction: column; gap: 16px;">
                      <div class="ship-val" style="font-size: 18px;">${order.shippingAddress || ''}</div>
                      <div class="ship-val"></div>
                    </div>
                  </div>
                  <div style="display: flex; align-items: flex-start; gap: 8px;">
                    <span class="ship-label">ĐIỆN THOẠI:</span>
                    <div class="ship-val ship-val-lg">${order.customerPhone || ''}</div>
                  </div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
        <script>
          window.onload = () => {
            setTimeout(() => {
              window.focus();
              window.print();
              window.onafterprint = () => window.close();
            }, 500);
          };
        </script>
      </body>
    </html>
  `;
};
