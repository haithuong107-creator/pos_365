import { doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Customer } from '../types';

const PRODUCTS: Partial<Product>[] = [
  { name: 'HP EliteBook 830 G7 i5-10210U /ram 8GB/ssd 256GB/ màn 13,3" FHD', sku: 'HP-830G7-01', barcode: '893000001', category: 'Laptops', unit: 'cái', buyPrice: 4400000, sellPrice: 5200000, taxRate: 10, stock: 5, minStock: 2 },
  { name: 'ThinkPad T14 Gen1 Core I5-10310U/ram 16G/ssd 256G/ màn 14" FHD IPS', sku: 'TP-T14G1-02', barcode: '893000002', category: 'Laptops', unit: 'cái', buyPrice: 4000000, sellPrice: 4800000, taxRate: 10, stock: 3, minStock: 2 },
  { name: 'Dell Latitude 3301 i3-8145U/ram 4g/ssd 128GB/ màn 13,3" HD', sku: 'DELL-3301-03', barcode: '893000003', category: 'Laptops', unit: 'cái', buyPrice: 2100000, sellPrice: 2500000, taxRate: 10, stock: 8, minStock: 2 },
  { name: 'ThinkPad P51S Core I7 6500U/ram 8G/ssd 512G/vga M520M/ màn 15,6"FHD', sku: 'TP-P51S-04', barcode: '893000004', category: 'Laptops', unit: 'cái', buyPrice: 4000000, sellPrice: 4800000, taxRate: 10, stock: 2, minStock: 1 },
  { name: 'HP 450 G8 i7 - 1165g7 / ram 8g / ssd 512g / màn 15,6" FHD', sku: 'HP-450G8-05', barcode: '893000005', category: 'Laptops', unit: 'cái', buyPrice: 7300000, sellPrice: 8600000, taxRate: 10, stock: 4, minStock: 2 },
  { name: 'DELL 3500 - i5 8265 / ram 8g / ssd 256g / màn 15,6" FHD', sku: 'DELL-3500-06', barcode: '893000006', category: 'Laptops', unit: 'cái', buyPrice: 3300000, sellPrice: 3900000, taxRate: 10, stock: 6, minStock: 2 },
  { name: 'DELL 3590 - i5 7200 / ram 8g / ssd 256g / màn 15,6" FHD', sku: 'DELL-3590-07', barcode: '893000007', category: 'Laptops', unit: 'cái', buyPrice: 3100000, sellPrice: 3700000, taxRate: 10, stock: 5, minStock: 2 },
  { name: 'HP 450 G6 i5 - 8265 / ram 8g / ssd 256g / màn 15,6" FHD', sku: 'HP-450G6-08', barcode: '893000008', category: 'Laptops', unit: 'cái', buyPrice: 4100000, sellPrice: 4850000, taxRate: 10, stock: 4, minStock: 2 },
  { name: 'DELL 5590 - i5 8265 / ram 8g / ssd 256g / màn 15,6" HD', sku: 'DELL-5590-09', barcode: '893000009', category: 'Laptops', unit: 'cái', buyPrice: 3100000, sellPrice: 3700000, taxRate: 10, stock: 7, minStock: 2 },
  { name: 'HP 650 G5 i5 - 8265 / ram 8g / ssd 256g / màn 15,6" FHD', sku: 'HP-650G5-10', barcode: '893000010', category: 'Laptops', unit: 'cái', buyPrice: 3800000, sellPrice: 4500000, taxRate: 10, stock: 3, minStock: 2 },
  { name: 'HP 450 G5 i3 - 7020 / ram 8g / ssd 128g / màn 15,6" HD', sku: 'HP-450G5-11', barcode: '893000011', category: 'Laptops', unit: 'cái', buyPrice: 2500000, sellPrice: 3000000, taxRate: 10, stock: 10, minStock: 3 },
  { name: 'Hp 450g5 i5 - 8250 / ram 8g / ssd 256g / màn 15,6" HD', sku: 'HP-450G5-12', barcode: '893000012', category: 'Laptops', unit: 'cái', buyPrice: 3600000, sellPrice: 4300000, taxRate: 10, stock: 5, minStock: 2 },
  { name: 'Dell 5320 i5 - 1135g7 / ram 8g / ssd 256g / màn 13,3" FHD', sku: 'DELL-5320-13', barcode: '893000013', category: 'Laptops', unit: 'cái', buyPrice: 5000000, sellPrice: 5900000, taxRate: 10, stock: 4, minStock: 2 },
  { name: 'HP 450g3 i3 6100 / ram 8g / ssd 128g / màn 15,6" HD', sku: 'HP-450G3-14', barcode: '893000014', category: 'Laptops', unit: 'cái', buyPrice: 2100000, sellPrice: 2500000, taxRate: 10, stock: 12, minStock: 3 },
  { name: 'HP 450g3 i5 6200 / ram 8g / ssd 128g / màn 15,6" HD', sku: 'HP-450G3-15', barcode: '893000015', category: 'Laptops', unit: 'cái', buyPrice: 2500000, sellPrice: 3000000, taxRate: 10, stock: 8, minStock: 2 },
  { name: 'dell 3590 i7 8550 - ram 8g - ssd 256g - màn 15.6" HD - vga AMD radeon R7 M460', sku: 'DELL-3590-16', barcode: '893000016', category: 'Laptops', unit: 'cái', buyPrice: 4900000, sellPrice: 5800000, taxRate: 10, stock: 2, minStock: 1 },
  { name: 'Hp 450g5 i7- 8550 / ram 8g / ssd 256g / màn 15,6" FHD', sku: 'HP-450G5-17', barcode: '893000017', category: 'Laptops', unit: 'cái', buyPrice: 4000000, sellPrice: 4800000, taxRate: 10, stock: 4, minStock: 2 },
  { name: 'HP EliteBook 830 G5 i3-8130 /ram 8GB/ssd 256GB/ màn 13,3" FHD', sku: 'HP-830G5-18', barcode: '893000018', category: 'Laptops', unit: 'cái', buyPrice: 3400000, sellPrice: 4000000, taxRate: 10, stock: 6, minStock: 2 },
  { name: 'HP 430 G8 i3-1115 G4 /ram 8GB/ssd 256GB/ màn 13,3" FHD', sku: 'HP-430G8-19', barcode: '893000019', category: 'Laptops', unit: 'cái', buyPrice: 4200000, sellPrice: 5000000, taxRate: 10, stock: 5, minStock: 2 },
  { name: 'Lenovo L590 i5 - 8365 / ram 8g / ssd 256g / màn 15,6" HD', sku: 'LEN-L590-20', barcode: '893000020', category: 'Laptops', unit: 'cái', buyPrice: 3500000, sellPrice: 4200000, taxRate: 10, stock: 4, minStock: 2 },
  { name: 'Dell 5511 i7 10850H / ram 16G / ssd 512G/ VGA MX 250 / màn 15,6" FHD', sku: 'DELL-5511-21', barcode: '893000021', category: 'Laptops', unit: 'cái', buyPrice: 6800000, sellPrice: 8000000, taxRate: 10, stock: 2, minStock: 1 },
  { name: 'HP 830 G5 i3-8150 /ram 8GB/ssd 256GB/ màn 13,3" FHD', sku: 'HP-830G5-22', barcode: '893000022', category: 'Laptops', unit: 'cái', buyPrice: 3400000, sellPrice: 4000000, taxRate: 10, stock: 5, minStock: 2 },
  { name: 'HP 430 G7 i3-10115 /ram 8GB/ssd 256GB/ màn 13,3" HD', sku: 'HP-430G7-23', barcode: '893000023', category: 'Laptops', unit: 'cái', buyPrice: 3500000, sellPrice: 4100000, taxRate: 10, stock: 6, minStock: 2 },
  { name: 'Hp 450g7 i5 gen 10 - ram 8g - ssd 256g - màn 15.6" FHD', sku: 'HP-450G7-24', barcode: '893000024', category: 'Laptops', unit: 'cái', buyPrice: 4900000, sellPrice: 5800000, taxRate: 10, stock: 4, minStock: 2 },
  { name: 'Hp 450g6 i3 gen 8 - ram 8g - ssd 128g - màn 15.6" HD', sku: 'HP-450G6-25', barcode: '893000025', category: 'Laptops', unit: 'cái', buyPrice: 3000000, sellPrice: 3600000, taxRate: 10, stock: 7, minStock: 2 },
  { name: 'Dell 5490 i5 gen 7 - ram 8g - ssd 128g - màn 14" HD', sku: 'DELL-5490-26', barcode: '893000026', category: 'Laptops', unit: 'cái', buyPrice: 3000000, sellPrice: 3600000, taxRate: 10, stock: 5, minStock: 2 },
  { name: 'Hp 250g7 i5 gen 8 - ram 8g - ssd 256g - màn 15.6" FHD', sku: 'HP-250G7-27', barcode: '893000027', category: 'Laptops', unit: 'cái', buyPrice: 3200000, sellPrice: 3800000, taxRate: 10, stock: 6, minStock: 2 },
  { name: 'Hp 450g5 i5 gen 7 - ram 8g - ssd 256g - màn 15.6" FHD', sku: 'HP-450G5-28', barcode: '893000028', category: 'Laptops', unit: 'cái', buyPrice: 3400000, sellPrice: 4000000, taxRate: 10, stock: 5, minStock: 2 },
];

const CUSTOMERS: Partial<Customer>[] = [
  { name: 'Nguyễn Văn An', phone: '0901234567' },
  { name: 'Trần Thị Bình', phone: '0912345678' },
  { name: 'Lê Văn Cường', phone: '0923456789' },
  { name: 'Phạm Thị Dung', phone: '0934567890' },
  { name: 'Hoàng Văn Em', phone: '0945678901' },
  { name: 'Ngô Thị Phương', phone: '0956789012' },
  { name: 'Vũ Văn Giang', phone: '0967890123' },
  { name: 'Đặng Thị Hoa', phone: '0978901234' },
  { name: 'Bùi Văn Hùng', phone: '0989012345' },
  { name: 'Đỗ Thị Lan', phone: '0990123456' },
  { name: 'Hồ Văn Minh', phone: '0321234567' },
  { name: 'Lý Thị Ngọc', phone: '0332345678' },
  { name: 'Phan Văn Nam', phone: '0343456789' },
  { name: 'Trương Thị Oanh', phone: '0354567890' },
  { name: 'Dương Văn Phúc', phone: '0365678901' },
  { name: 'Lâm Thị Quỳnh', phone: '0376789012' },
  { name: 'Võ Văn Sơn', phone: '0387890123' },
  { name: 'Mai Thị Tuyết', phone: '0398901234' },
  { name: 'Đào Văn Việt', phone: '0819012345' },
  { name: 'Lương Thị Xuân', phone: '0820123456' },
];

export async function seedTestData() {
  const batch = writeBatch(db);

  // Seed Products
  PRODUCTS.forEach((p) => {
    const id = p.sku || Math.random().toString(36).substring(7);
    const docRef = doc(db, 'products', id);
    batch.set(docRef, {
      ...p,
      id,
      updatedAt: new Date().toISOString(),
    });
  });

  // Seed Customers
  CUSTOMERS.forEach((c) => {
    const docRef = doc(db, 'customers', c.phone!);
    batch.set(docRef, {
      ...c,
      purchaseHistory: [],
      updatedAt: new Date().toISOString(),
    });
  });

  await batch.commit();
}
