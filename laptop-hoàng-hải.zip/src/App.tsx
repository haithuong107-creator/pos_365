import React, { useState, useEffect, useMemo } from 'react';
import { 
  auth, db, handleFirestoreError 
} from './firebase';
import { 
  onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User 
} from 'firebase/auth';
import { 
  collection, doc, onSnapshot, setDoc, updateDoc, addDoc, query, orderBy, limit, getDoc, getDocFromServer, writeBatch, deleteDoc
} from 'firebase/firestore';
import { 
  LayoutDashboard, Package, ShoppingCart, BarChart3, LogOut, Search, Plus, Minus, Trash2, Scan, Sparkles, User as UserIcon, ChevronRight, AlertCircle, CheckCircle2, Users, Receipt, Settings, Filter, FileText, FileUp, Bell, Wrench, ShieldCheck, Phone, MapPin, Send, MessageSquare, UserPlus, Zap, Image as ImageIcon, Edit2, X, Truck, Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell
} from 'recharts';
import { read, utils, write } from 'xlsx';
import { Scanner } from './components/Scanner';
import { getInventoryAdvice, generateMarketingMessage, analyzeCustomers, getUpsellSuggestions, chatWithAssistant, getQuotationSuggestions, extractProductDataFromImage } from './services/gemini';
import { generateVietQRUrl, sendZaloNotification, sendSMSNotification, getOrderNotificationMessage } from './utils/posUtils';
import { seedTestData } from './utils/seedData';
import { generateInvoiceHtml } from './utils/printInvoice';
import Invoice from './components/Invoice';
import { Product, Order, UserProfile, OperationType, OrderItem, Customer, VATReport, Quotation, OrderStatus, PaymentType } from './types';
import ReactMarkdown from 'react-markdown';

// --- Components ---

const Button = ({ children, onClick, variant = 'primary', className = '', disabled = false, icon: Icon }: any) => {
  const variants: any = {
    primary: 'bg-slate-900 text-white hover:bg-slate-800',
    secondary: 'bg-white text-slate-900 border border-slate-200 hover:bg-slate-50',
    danger: 'bg-red-500 text-white hover:bg-red-600',
    ghost: 'bg-transparent text-slate-600 hover:bg-slate-100',
    accent: 'bg-emerald-500 text-white hover:bg-emerald-600',
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-medium transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none ${variants[variant]} ${className}`}
    >
      {Icon && <Icon size={18} />}
      {children}
    </button>
  );
};

const Card = ({ children, className = '' }: any) => (
  <div className={`bg-white rounded-2xl border border-slate-100 shadow-sm p-6 ${className}`}>
    {children}
  </div>
);

const Input = ({ label, ...props }: any) => (
  <div className="flex flex-col gap-1.5 w-full">
    {label && <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</label>}
    <input
      {...props}
      className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
    />
  </div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [vatReports, setVatReports] = useState<VATReport[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [staff, setStaff] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [customerInfo, setCustomerInfo] = useState({ name: '', phone: '' });
  const [discount, setDiscount] = useState(0);
  const [shippingFee, setShippingFee] = useState(0);
  const [amountPaid, setAmountPaid] = useState(0);
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([]);
  const [showCustomerSuggestions, setShowCustomerSuggestions] = useState(false);

  const [paymentType, setPaymentType] = useState<PaymentType>(PaymentType.Full);
  const [shippingAddress, setShippingAddress] = useState('');
  const [orderNote, setOrderNote] = useState('');
  const [showInvoice, setShowInvoice] = useState(false);
  const [autoPrintInvoice, setAutoPrintInvoice] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);

  const handleCustomerInput = (field: 'name' | 'phone', value: string) => {
    setCustomerInfo(prev => ({ ...prev, [field]: value }));
    
    if (value.length >= 2) {
      const filtered = customers.filter(c => 
        c.name.toLowerCase().includes(value.toLowerCase()) || 
        c.phone.includes(value)
      );
      setFilteredCustomers(filtered);
      setShowCustomerSuggestions(filtered.length > 0);
    } else {
      setShowCustomerSuggestions(false);
    }
  };

  const handleProductSearch = (query: string) => {
    setSearchQuery(query);
    if (query.length >= 2) {
      const filtered = products.filter(p => 
        p.name.toLowerCase().includes(query.toLowerCase()) || 
        p.sku.toLowerCase().includes(query.toLowerCase()) ||
        p.barcode?.includes(query)
      );
      setFilteredProducts(filtered);
      setShowProductSuggestions(filtered.length > 0);
    } else {
      setShowProductSuggestions(false);
    }
  };

  const selectProduct = (product: Product) => {
    addToCart(product);
    setSearchQuery('');
    setShowProductSuggestions(false);
  };

  const selectCustomer = (customer: Customer) => {
    setCustomerInfo({ name: customer.name, phone: customer.phone });
    if (customer.address) setShippingAddress(customer.address);
    setShowCustomerSuggestions(false);
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.customer-suggestion-container')) {
        setShowCustomerSuggestions(false);
      }
      if (!target.closest('.product-suggestion-container')) {
        setShowProductSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Auto-update amountPaid for Full payment
  useEffect(() => {
    if (paymentType === PaymentType.Full) {
      const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const vatAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0);
      const total = subtotal + vatAmount + shippingFee - discount;
      setAmountPaid(Math.max(0, total));
    }
  }, [cart, discount, shippingFee, paymentType]);
  const [selectedCategory, setSelectedCategory] = useState<string>('Tất cả');
  const [searchQuery, setSearchQuery] = useState('');
  const [showProductSuggestions, setShowProductSuggestions] = useState(false);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [showScanner, setShowScanner] = useState(false);

  // AI Assistant State
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: 'Xin chào! Tôi là Trợ lý ảo Hoàng Hải Empire. Tôi có thể giúp bạn tra cứu kho hàng, khách hàng, báo giá hoặc tư vấn sản phẩm. Bạn cần hỗ trợ gì hôm nay?' }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatEndRef = React.useRef<HTMLDivElement>(null);

  // Quotation State
  const [quotationItems, setQuotationItems] = useState<OrderItem[]>([]);
  const [quotationCustomer, setQuotationCustomer] = useState({ name: '', phone: '', email: '' });
  const [quotationDiscount, setQuotationDiscount] = useState(0);
  const [quotationNote, setQuotationNote] = useState('');
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string | null>(null);
  const [customerNeeds, setCustomerNeeds] = useState('');
  const [storeSettings, setStoreSettings] = useState({
    name: 'Hoàng Hải Empire',
    phone: '0934 393 404',
    address: 'Số 10 Ngân Sơn, Hải Dương'
  });
  const [isAiPanelOpen, setIsAiPanelOpen] = useState(false);

  // Customer Management State
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [customerForm, setCustomerForm] = useState({ name: '', phone: '', email: '', address: '', note: '' });

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (activeTab === 'ai-assistant') {
      scrollToBottom();
    }
  }, [chatMessages, activeTab]);

  const handleSendMessage = async (e?: React.FormEvent, overrideMessage?: string) => {
    if (e) e.preventDefault();
    const messageToSend = overrideMessage || chatInput.trim();
    if (!messageToSend || isChatLoading) return;

    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: messageToSend }]);
    setIsChatLoading(true);

    try {
      const history = chatMessages.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }));

      const response = await chatWithAssistant(messageToSend, history, {
        products,
        customers,
        orders,
        reminders: stats.reminders
      });

      setChatMessages(prev => [...prev, { role: 'model', text: response || 'Xin lỗi, tôi gặp sự cố khi xử lý yêu cầu.' }]);
    } catch (error) {
      console.error('AI Chat Error:', error);
      setChatMessages(prev => [...prev, { role: 'model', text: 'Rất tiếc, hệ thống AI đang bận. Vui lòng thử lại sau.' }]);
    } finally {
      setIsChatLoading(false);
    }
  };
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [customerAnalysis, setCustomerAnalysis] = useState<string | null>(null);
  const [upsellSuggestions, setUpsellSuggestions] = useState<string | null>(null);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isOrderDetailsModalOpen, setIsOrderDetailsModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isEditingOrder, setIsEditingOrder] = useState(false);
  const [productNameSuggestions, setProductNameSuggestions] = useState<Product[]>([]);
  const [skuSuggestions, setSkuSuggestions] = useState<Product[]>([]);
  const [showNameSuggestions, setShowNameSuggestions] = useState(false);
  const [showSkuSuggestions, setShowSkuSuggestions] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    sku: '',
    barcode: '',
    category: 'Laptop',
    unit: 'Cái',
    buyPrice: 0,
    sellPrice: 0,
    taxRate: 10,
    stock: 0,
    minStock: 5
  });
  const [isImageImportModalOpen, setIsImageImportModalOpen] = useState(false);
  const [extractedProducts, setExtractedProducts] = useState<any[]>([]);
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const docRef = doc(db, 'users', u.uid);
        onSnapshot(docRef, (docSnap) => {
          if (docSnap.exists()) {
            setProfile(docSnap.data() as UserProfile);
          } else {
            // New user - default to sales
            const newProfile: UserProfile = {
              uid: u.uid,
              email: u.email || '',
              displayName: u.displayName || 'User',
              role: 'admin', // Default to admin for now
              createdAt: new Date().toISOString()
            };
            setDoc(docRef, newProfile).catch(err => handleFirestoreError(err, OperationType.CREATE, 'users'));
          }
        });
      } else {
        setProfile(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  // Data Listeners
  useEffect(() => {
    if (!user) return;

    const productsUnsubscribe = onSnapshot(collection(db, 'products'), (snapshot) => {
      const fetchedProducts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
      setProducts(fetchedProducts);
      const cats = Array.from(new Set(fetchedProducts.map(p => p.category).filter(Boolean)));
      setCategories(cats);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'products'));

    const ordersUnsubscribe = onSnapshot(
      query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(100)),
      (snapshot) => {
        setOrders(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order)));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'orders')
    );

    const customersUnsubscribe = onSnapshot(collection(db, 'customers'), (snapshot) => {
      setCustomers(snapshot.docs.map(doc => ({ ...doc.data() } as unknown as Customer)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'customers'));

    const vatUnsubscribe = onSnapshot(collection(db, 'vat_reports'), (snapshot) => {
      setVatReports(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as unknown as VATReport)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'vat_reports'));

    const quotationsUnsubscribe = onSnapshot(collection(db, 'quotations'), (snapshot) => {
      setQuotations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as unknown as Quotation)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'quotations'));

    const settingsUnsubscribe = onSnapshot(doc(db, 'settings', 'store'), (docSnap) => {
      if (docSnap.exists()) {
        setStoreSettings(docSnap.data() as any);
      }
    }, (err) => handleFirestoreError(err, OperationType.GET, 'settings/store'));

    let staffUnsubscribe = () => {};
    if (profile?.role === 'admin') {
      staffUnsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
        setStaff(snapshot.docs.map(doc => doc.data() as UserProfile));
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'users'));
    }

    return () => {
      productsUnsubscribe();
      ordersUnsubscribe();
      customersUnsubscribe();
      vatUnsubscribe();
      quotationsUnsubscribe();
      settingsUnsubscribe();
      staffUnsubscribe();
    };
  }, [user, profile?.role]);

  // Connection Test
  useEffect(() => {
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();
  }, []);

  const notify = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => signOut(auth);

  const handleSaveQuotation = async (status: 'Draft' | 'Sent' = 'Draft') => {
    if (quotationItems.length === 0) {
      notify('error', 'Vui lòng chọn ít nhất một sản phẩm');
      return;
    }
    if (!quotationCustomer.name || !quotationCustomer.phone) {
      notify('error', 'Vui lòng nhập tên và số điện thoại khách hàng');
      return;
    }
    if (!user || !profile) return;

    try {
      const subtotal = quotationItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      const vatAmount = quotationItems.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0);
      const totalAmount = subtotal + vatAmount - quotationDiscount;

      const quotationData: Partial<Quotation> = {
        customerName: quotationCustomer.name,
        customerPhone: quotationCustomer.phone,
        customerEmail: quotationCustomer.email,
        items: quotationItems,
        subtotal,
        vatAmount,
        discount: quotationDiscount,
        totalAmount,
        note: quotationNote,
        status,
        sellerId: user.uid,
        sellerName: profile.displayName,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'quotations'), quotationData);
      notify('success', status === 'Draft' ? 'Đã lưu bản nháp báo giá' : 'Đã lưu và gửi báo giá');
      
      // Reset form
      setQuotationItems([]);
      setQuotationCustomer({ name: '', phone: '', email: '' });
      setQuotationDiscount(0);
      setQuotationNote('');
      setAiSuggestions(null);
      setCustomerNeeds('');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'quotations');
      notify('error', 'Lỗi khi lưu báo giá');
    }
  };

  const handleSendQuotation = async (method: 'email' | 'message') => {
    if (quotationItems.length === 0) {
      notify('error', 'Vui lòng chọn ít nhất một sản phẩm');
      return;
    }
    
    const subtotal = quotationItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const vatAmount = quotationItems.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0);
    const totalAmount = subtotal + vatAmount - quotationDiscount;

    const itemsText = quotationItems.map(item => `- ${item.name}: ${item.quantity} x ${item.price.toLocaleString()}đ`).join('\n');
    const message = `Kính gửi ${quotationCustomer.name},\n\nHoàng Hải Empire xin gửi báo giá cho quý khách:\n${itemsText}\n\nTổng cộng: ${totalAmount.toLocaleString()}đ\n\nTrân trọng!`;

    if (method === 'email') {
      if (!quotationCustomer.email) {
        notify('error', 'Vui lòng nhập email khách hàng');
        return;
      }
      window.open(`mailto:${quotationCustomer.email}?subject=Bao gia tu Hoang Hai Empire&body=${encodeURIComponent(message)}`);
    } else {
      window.open(`https://zalo.me/${quotationCustomer.phone.replace(/^0/, '84')}`);
      // Copy to clipboard for convenience
      navigator.clipboard.writeText(message);
      notify('success', 'Đã sao chép nội dung báo giá và mở Zalo');
    }
    
    await handleSaveQuotation('Sent');
  };

  const handleAiSuggestQuotation = async () => {
    if (!customerNeeds.trim()) {
      notify('error', 'Vui lòng nhập nhu cầu của khách hàng');
      return;
    }
    setIsAiSuggesting(true);
    try {
      const suggestions = await getQuotationSuggestions(customerNeeds, products);
      setAiSuggestions(suggestions);
    } catch (err) {
      console.error(err);
      notify('error', 'Lỗi khi lấy gợi ý từ AI');
    } finally {
      setIsAiSuggesting(false);
    }
  };

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerForm.name || !customerForm.phone) {
      notify('error', 'Vui lòng nhập tên và số điện thoại!');
      return;
    }
    try {
      const customerData = {
        ...customerForm,
        updatedAt: new Date().toISOString(),
        purchaseHistory: editingCustomer?.purchaseHistory || []
      };
      await setDoc(doc(db, 'customers', customerForm.phone), customerData);
      notify('success', `Đã ${editingCustomer ? 'cập nhật' : 'thêm'} khách hàng thành công!`);
      setIsCustomerModalOpen(false);
      setEditingCustomer(null);
      setCustomerForm({ name: '', phone: '', email: '', address: '', note: '' });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'customers');
    }
  };

  const handleDeleteCustomer = async (phone: string) => {
    if (!window.confirm('Bạn có chắc chắn muốn xoá khách hàng này?')) return;
    try {
      await deleteDoc(doc(db, 'customers', phone));
      notify('success', 'Đã xoá khách hàng thành công!');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'customers');
    }
  };

  const handleQuickAddCustomer = async (name: string, phone: string) => {
    if (!name || !phone) {
      notify('error', 'Vui lòng nhập tên và số điện thoại!');
      return;
    }
    try {
      await setDoc(doc(db, 'customers', phone), {
        name,
        phone,
        updatedAt: new Date().toISOString(),
        purchaseHistory: []
      });
      notify('success', 'Đã thêm nhanh khách hàng!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'customers');
    }
  };

  const addToQuotation = (product: Product) => {
    setQuotationItems(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item => 
          item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { 
        productId: product.id, 
        name: product.name, 
        quantity: 1, 
        price: product.sellPrice,
        taxRate: product.taxRate 
      }];
    });
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item => 
          item.productId === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { 
        productId: product.id, 
        name: product.name, 
        quantity: 1, 
        price: product.sellPrice,
        taxRate: product.taxRate 
      }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.productId === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const handleCheckout = async () => {
    if (cart.length === 0) {
      notify('error', 'Giỏ hàng đang trống');
      return;
    }
    if (!user || !profile) {
      notify('error', 'Vui lòng đăng nhập để thực hiện thanh toán');
      return;
    }

    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const vatAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0);
    const totalAmount = subtotal + vatAmount + shippingFee - discount;
    const finalAmount = totalAmount; // For now, same as totalAmount
    const debt = Math.max(0, totalAmount - amountPaid);

    const orderData: Omit<Order, 'id'> = {
      customerName: customerInfo.name || 'Khách lẻ',
      customerPhone: customerInfo.phone || '',
      items: cart,
      subtotal,
      vatAmount,
      discount,
      shippingFee,
      totalAmount,
      finalAmount,
      amountPaid,
      debt,
      status: OrderStatus.Completed,
      paymentType,
      shippingAddress,
      note: orderNote,
      sellerId: user.uid,
      sellerName: profile.displayName,
      createdAt: new Date().toISOString()
    };

    try {
      const batch = writeBatch(db);
      
      // 1. Create Order
      const orderRef = doc(collection(db, 'orders'));
      batch.set(orderRef, orderData);

      // 2. Update Stock
      for (const item of cart) {
        const product = products.find(p => p.id === item.productId);
        if (product) {
          batch.update(doc(db, 'products', product.id), {
            stock: product.stock - item.quantity,
            updatedAt: new Date().toISOString()
          });
        }
      }

      // 3. Create VAT Report (Output)
      const vatReportRef = doc(collection(db, 'vat_reports'));
      batch.set(vatReportRef, {
        type: 'Output',
        amount: subtotal,
        taxAmount: vatAmount,
        taxRate: 0, // Mixed rates in one order
        referenceId: orderRef.id,
        description: `Thuế đầu ra đơn hàng ${orderRef.id}`,
        createdAt: new Date().toISOString()
      });

      // 4. Update/Create Customer
      if (customerInfo.phone) {
        const customerRef = doc(db, 'customers', customerInfo.phone);
        const customerSnap = await getDoc(customerRef);
        
        if (customerSnap.exists()) {
          batch.update(customerRef, {
            purchaseHistory: [...(customerSnap.data().purchaseHistory || []), orderRef.id],
            updatedAt: new Date().toISOString()
          });
        } else {
          batch.set(customerRef, {
            phone: customerInfo.phone,
            name: customerInfo.name || 'Khách hàng mới',
            purchaseHistory: [orderRef.id],
            updatedAt: new Date().toISOString()
          });
        }
      }

      await batch.commit();
      const completedOrder: Order = { id: orderRef.id, ...orderData };
      setLastOrder(completedOrder);
      setShowSuccessModal(true);
      setCart([]);
      setCustomerInfo({ name: '', phone: '' });
      setDiscount(0);
      setShippingFee(0);
      setAmountPaid(0);
      setShippingAddress('');
      setOrderNote('');
      setPaymentType(PaymentType.Full);
      setUpsellSuggestions(null);
      notify('success', 'Thanh toán thành công!');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'orders');
      notify('error', 'Lỗi khi thanh toán');
    }
  };

  const handleScan = (barcode: string) => {
    const product = products.find(p => p.barcode === barcode);
    if (product) {
      addToCart(product);
      setShowScanner(false);
      notify('success', `Đã thêm ${product.name}`);
    } else {
      notify('error', 'Không tìm thấy sản phẩm');
    }
  };

  const handlePrint = (order: Order, auto: boolean = false) => {
    console.log('handlePrint called for order:', order.id, 'auto:', auto);
    
    if (!auto) {
      setCurrentOrder(order);
      setShowInvoice(true);
      setAutoPrintInvoice(false);
      return;
    }

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      notify('error', 'Trình duyệt đã chặn cửa sổ in. Vui lòng cho phép bật lên.');
      return;
    }

    const invoiceHtml = generateInvoiceHtml(order);
    printWindow.document.write(invoiceHtml);
    printWindow.document.close();
  };

  const fetchAiAdvice = async () => {
    setIsAiLoading(true);
    try {
      const advice = await getInventoryAdvice(products, orders as any);
      setAiAdvice(advice || "Không có lời khuyên nào.");
    } catch (err) {
      console.error(err);
      setAiAdvice("Lỗi khi kết nối với AI.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const fetchCustomerAnalysis = async () => {
    setIsAiLoading(true);
    try {
      const analysis = await analyzeCustomers(customers, orders);
      setCustomerAnalysis(analysis || "Không có phân tích nào.");
    } catch (err) {
      console.error(err);
      setCustomerAnalysis("Lỗi khi kết nối với AI.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const fetchUpsellSuggestions = async () => {
    if (cart.length === 0) return;
    setIsAiLoading(true);
    try {
      const suggestions = await getUpsellSuggestions(cart, products);
      setUpsellSuggestions(suggestions || "Không có gợi ý nào.");
    } catch (err) {
      console.error(err);
      setUpsellSuggestions("Lỗi khi kết nối với AI.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const stats = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const todayOrders = orders.filter(s => s.createdAt.startsWith(today));
    const revenue = todayOrders.reduce((sum, s) => sum + s.totalAmount, 0);
    const lowStock = products.filter(p => p.stock <= p.minStock).length;
    const criticalLaptops = products.filter(p => p.category === 'Electronics' && p.stock < 2);
    
    // Calculate reminders
    const now = new Date();
    const reminders = orders.filter(order => {
      const orderDate = new Date(order.createdAt);
      const diffMonths = (now.getFullYear() - orderDate.getFullYear()) * 12 + (now.getMonth() - orderDate.getMonth());
      
      const hasPrinter = order.items.some(item => 
        item.name.toLowerCase().includes('máy in') || item.name.toLowerCase().includes('mực')
      );
      const hasLaptop = order.items.some(item => 
        item.name.toLowerCase().includes('laptop') || item.name.toLowerCase().includes('dell') || item.name.toLowerCase().includes('hp')
      );

      if (hasPrinter && diffMonths >= 4) return true;
      if (hasLaptop && diffMonths >= 6) return true;
      return false;
    });

    // Category distribution for pie chart
    const categoryData = categories.map(cat => ({
      name: cat,
      value: products.filter(p => p.category === cat).length
    })).filter(c => c.value > 0);

    return { revenue, count: todayOrders.length, lowStock, criticalLaptops, reminders, categoryData };
  }, [orders, products, categories]);

  const exportToCSV = () => {
    const headers = ['ID', 'Date', 'Customer', 'Total', 'Seller'];
    const rows = orders.map(o => [
      o.id,
      o.createdAt,
      o.customerName,
      o.totalAmount,
      o.sellerName
    ]);
    
    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `SmartSales_Orders_${format(new Date(), 'yyyyMMdd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const seedData = async () => {
    setIsAiLoading(true);
    try {
      await seedTestData();
      notify('success', 'Đã nạp 30 sản phẩm và 20 khách hàng mẫu!');
    } catch (err) {
      console.error(err);
      notify('error', 'Lỗi khi nạp dữ liệu mẫu');
    } finally {
      setIsAiLoading(false);
    }
  };

  useEffect(() => {
    if (!isProductModalOpen) {
      setProductNameSuggestions([]);
      setSkuSuggestions([]);
      setShowNameSuggestions(false);
      setShowSkuSuggestions(false);
    }
  }, [isProductModalOpen]);

  const handleSaveProduct = async () => {
    if (!productForm.name || !productForm.sku) {
      notify('error', 'Vui lòng nhập tên và mã SKU!');
      return;
    }
    setIsAiLoading(true);
    try {
      const productData = {
        ...productForm,
        updatedAt: new Date().toISOString()
      };
      if (editingProduct) {
        // Check if SKU already exists on ANOTHER product
        const existingBySku = products.find(p => p.sku === productForm.sku && p.id !== editingProduct.id);
        if (existingBySku) {
          notify('error', `Mã SKU ${productForm.sku} đã được sử dụng bởi sản phẩm khác (${existingBySku.name})!`);
          setIsAiLoading(false);
          return;
        }
        await setDoc(doc(db, 'products', editingProduct.id), productData);
        notify('success', 'Đã cập nhật sản phẩm!');
      } else {
        // Check if SKU already exists
        const existingBySku = products.find(p => p.sku === productForm.sku);
        if (existingBySku) {
          if (window.confirm(`Sản phẩm với SKU ${productForm.sku} đã tồn tại (${existingBySku.name}). Bạn có muốn cập nhật sản phẩm này thay vì thêm mới?`)) {
            await setDoc(doc(db, 'products', existingBySku.id), {
              ...productData,
              id: existingBySku.id,
              stock: existingBySku.stock + (productForm.stock || 0) // Add to existing stock
            });
            notify('success', 'Đã cập nhật tồn kho cho sản phẩm hiện có!');
          } else {
            setIsAiLoading(false);
            return;
          }
        } else {
          const newRef = doc(collection(db, 'products'));
          await setDoc(newRef, { ...productData, id: newRef.id });
          notify('success', 'Đã thêm sản phẩm mới!');
        }
      }
      setIsProductModalOpen(false);
      setEditingProduct(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm('Bạn có chắc chắn muốn xoá sản phẩm này?')) return;
    try {
      await deleteDoc(doc(db, 'products', id));
      notify('success', 'Đã xoá sản phẩm!');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'products');
    }
  };

  const handleDeleteOrder = async (id: string) => {
    if (!window.confirm('Bạn có chắc chắn muốn xoá đơn hàng này? Thao tác này sẽ hoàn lại tồn kho.')) return;
    try {
      const orderToDelete = orders.find(o => o.id === id);
      if (!orderToDelete) return;

      const batch = writeBatch(db);
      
      // 1. Delete Order
      batch.delete(doc(db, 'orders', id));

      // 2. Return items to stock
      for (const item of orderToDelete.items) {
        const product = products.find(p => p.id === item.productId);
        if (product) {
          batch.update(doc(db, 'products', product.id), {
            stock: product.stock + item.quantity,
            updatedAt: new Date().toISOString()
          });
        }
      }

      await batch.commit();
      notify('success', 'Đã xoá đơn hàng và hoàn lại tồn kho!');
      setIsOrderDetailsModalOpen(false);
      setSelectedOrder(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'orders');
      notify('error', 'Lỗi khi xoá đơn hàng');
    }
  };

  const handleUpdateOrder = async (order: Order) => {
    try {
      const oldOrder = orders.find(o => o.id === order.id);
      if (!oldOrder) return;

      const batch = writeBatch(db);
      const { id, ...orderData } = order;
      
      // 1. Update Order
      batch.update(doc(db, 'orders', id), {
        ...orderData,
        updatedAt: new Date().toISOString()
      });

      // 2. Reconcile Stock
      const stockChanges: Record<string, number> = {};
      
      // First, return old items
      for (const item of oldOrder.items) {
        stockChanges[item.productId] = (stockChanges[item.productId] || 0) + item.quantity;
      }
      
      // Then, deduct new items
      for (const item of order.items) {
        stockChanges[item.productId] = (stockChanges[item.productId] || 0) - item.quantity;
      }

      // Apply changes
      for (const [productId, change] of Object.entries(stockChanges)) {
        if (change === 0) continue;
        const product = products.find(p => p.id === productId);
        if (product) {
          batch.update(doc(db, 'products', productId), {
            stock: product.stock + change,
            updatedAt: new Date().toISOString()
          });
        }
      }

      await batch.commit();
      notify('success', 'Đã cập nhật đơn hàng và điều chỉnh tồn kho!');
      setIsOrderDetailsModalOpen(false);
      setSelectedOrder(null);
      setIsEditingOrder(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'orders');
      notify('error', 'Lỗi khi cập nhật đơn hàng');
    }
  };

  const handleExcelImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAiLoading(true);
    try {
      const data = await file.arrayBuffer();
      const workbook = read(data);
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonData = utils.sheet_to_json<any>(worksheet);

      const batch = writeBatch(db);
      let added = 0;
      let updated = 0;

      for (const row of jsonData) {
        // Map columns based on user's request and common patterns
        const name = row['Tên Hàng'] || row['name'] || row['Name'] || row['Sản phẩm'];
        const buyPrice = Number(row['Giá Nhập'] || row['buyPrice'] || row['Buy Price'] || 0);
        const sellPrice = Number(row['Giá Bán'] || row['sellPrice'] || row['Sell Price'] || 0);
        const barcode = String(row['Barcode'] || row['barcode'] || row['Mã vạch'] || '');
        const category = row['Danh mục'] || row['category'] || row['Category'] || 'General';
        const stock = Number(row['Số lượng'] || row['stock'] || row['Stock'] || row['Tồn kho'] || 1);
        const sku = row['SKU'] || row['sku'] || '';

        if (!name) continue;

        // Try to find existing product by name or barcode
        const existing = products.find(p => 
          (barcode && p.barcode === barcode) || (p.name.toLowerCase() === name.toLowerCase())
        );

        if (existing) {
          batch.update(doc(db, 'products', existing.id), {
            buyPrice: buyPrice || existing.buyPrice,
            sellPrice: sellPrice || existing.sellPrice,
            stock: existing.stock + stock,
            updatedAt: new Date().toISOString()
          });
          updated++;
        } else {
          const newRef = doc(collection(db, 'products'));
          const newProduct: Omit<Product, 'id'> = {
            name,
            buyPrice,
            sellPrice,
            barcode: barcode || `BC-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
            category,
            stock,
            minStock: 5,
            sku: sku || `SKU-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
            unit: 'Cái',
            taxRate: 10,
            updatedAt: new Date().toISOString()
          };
          batch.set(newRef, newProduct);
          added++;
        }
      }

      await batch.commit();
      notify('success', `Đã nhập thành công: ${added} mới, ${updated} cập nhật.`);
    } catch (err) {
      console.error(err);
      notify('error', 'Lỗi khi đọc file Excel. Vui lòng kiểm tra định dạng file.');
    } finally {
      setIsAiLoading(false);
      e.target.value = ''; // Reset input
    }
  };

  const handleImageImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAiLoading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = (reader.result as string).split(',')[1];
        const data = await extractProductDataFromImage(base64String);
        setExtractedProducts(data);
        setIsImageImportModalOpen(true);
        setIsAiLoading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error(err);
      notify('error', 'Lỗi khi phân tích ảnh');
      setIsAiLoading(false);
    }
  };

  const saveExtractedProducts = async () => {
    setIsAiLoading(true);
    try {
      const batch = writeBatch(db);
      for (const p of extractedProducts) {
        // Check if SKU already exists
        const existingBySku = products.find(prod => prod.sku === p.sku);
        
        if (existingBySku) {
          // Update existing product stock
          const productRef = doc(db, 'products', existingBySku.id);
          batch.update(productRef, {
            stock: existingBySku.stock + (p.stock || 1),
            updatedAt: new Date().toISOString()
          });
        } else {
          // Create new product
          const productRef = doc(collection(db, 'products'));
          const newProduct = {
            ...p,
            id: productRef.id,
            sku: p.sku || `SKU-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
            barcode: p.barcode || Math.floor(Math.random() * 1000000000).toString(),
            category: p.category || 'Laptops',
            unit: p.unit || 'cái',
            buyPrice: p.buyPrice || Math.floor(p.sellPrice * 0.85),
            taxRate: 10,
            minStock: 2,
            stock: p.stock || 1,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          batch.set(productRef, newProduct);
        }
      }
      await batch.commit();
      notify('success', `Đã nhập/cập nhật ${extractedProducts.length} sản phẩm thành công!`);
      setIsImageImportModalOpen(false);
      setExtractedProducts([]);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
      notify('error', 'Lỗi khi lưu sản phẩm');
    } finally {
      setIsAiLoading(false);
    }
  };

  const downloadExcelTemplate = () => {
    const templateData = [
      {
        'Tên Hàng': 'Laptop HP EliteBook 830 G7',
        'Giá Nhập': 4500000,
        'Giá Bán': 5200000,
        'Số lượng': 5,
        'Danh mục': 'Laptop',
        'Barcode': 'HP830G7-001',
        'SKU': 'HP-ELITE-830'
      },
      {
        'Tên Hàng': 'Máy in Canon LBP 2900',
        'Giá Nhập': 2800000,
        'Giá Bán': 3500000,
        'Số lượng': 10,
        'Danh mục': 'Máy in',
        'Barcode': 'CANON2900-001',
        'SKU': 'CANON-2900'
      },
      {
        'Tên Hàng': 'Hộp mực 35A/85A',
        'Giá Nhập': 65000,
        'Giá Bán': 90000,
        'Số lượng': 50,
        'Danh mục': 'Hộp mực',
        'Barcode': 'INK35A-001',
        'SKU': 'INK-35A'
      }
    ];

    const worksheet = utils.json_to_sheet(templateData);
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, 'Template');
    
    const excelBuffer = write(workbook, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'SmartSales_Template_NhapHang.xlsx');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    notify('success', 'Đã tải file mẫu!');
  };

  const updateOrderStatus = async (orderId: string, status: OrderStatus) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), { status });
      setNotification({ message: 'Cập nhật trạng thái đơn hàng thành công', type: 'success' });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const updateUserRole = async (uid: string, newRole: 'admin' | 'sales') => {
    try {
      await updateDoc(doc(db, 'users', uid), { role: newRole });
      notify('success', 'Đã cập nhật quyền hạn');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'users');
    }
  };

  const deleteUser = async (uid: string) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa nhân viên này?')) return;
    try {
      await deleteDoc(doc(db, 'users', uid));
      notify('success', 'Đã xóa nhân viên');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'users');
    }
  };

  if (loading) return (
    <div className="h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-slate-200 border-t-slate-900 rounded-full animate-spin"></div>
        <p className="text-slate-500 font-medium">Đang tải hệ thống...</p>
      </div>
    </div>
  );

  if (!user) return (
    <div className="h-screen flex flex-col items-center justify-center bg-slate-50 p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md text-center space-y-8"
      >
        <div className="space-y-2">
          <div className="w-20 h-20 bg-slate-900 rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-slate-900/20">
            <ShoppingCart className="text-white" size={40} />
          </div>
          <h1 className="text-4xl font-bold text-slate-900 tracking-tight">SmartSales AI</h1>
          <p className="text-slate-500">Hệ thống quản lý bán hàng thế hệ mới</p>
        </div>
        
        <Card className="space-y-6">
          <p className="text-sm text-slate-600">Vui lòng đăng nhập bằng tài khoản Google để tiếp tục</p>
          <Button onClick={handleLogin} className="w-full py-4 text-lg" icon={UserIcon}>
            Đăng nhập với Google
          </Button>
        </Card>
      </motion.div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-72 bg-white flex flex-col fixed h-full border-r border-slate-100 z-20">
        <div className="p-6 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 flex flex-col rounded-lg overflow-hidden shadow-sm">
              <div className="flex-1 bg-red-600"></div>
              <div className="flex-1 bg-sky-500"></div>
            </div>
            <div className="flex flex-col">
              <span className="text-red-600 font-black text-lg leading-none">Laptop</span>
              <span className="text-sky-500 font-bold text-lg leading-none">Hoàng Hải</span>
            </div>
          </div>

          <div className="bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-2 flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Firebase Connected</span>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto scrollbar-hide">
          {[
            { id: 'dashboard', label: 'Tổng quan', icon: LayoutDashboard },
            { id: 'pos', label: 'Bán hàng', icon: ShoppingCart },
            { id: 'orders', label: 'Đơn hàng', icon: FileText },
            { id: 'inventory', label: 'Kho hàng', icon: Package },
            { id: 'quotations', label: 'Danh mục', icon: Filter },
            { id: 'customers', label: 'Khách hàng', icon: Users },
            { id: 'reports', label: 'Báo cáo', icon: BarChart3 },
            { id: 'vat', label: 'Thuế VAT', icon: Receipt },
            { id: 'staff', label: 'Nhân viên', icon: UserIcon, adminOnly: true },
            { id: 'settings', label: 'Cài đặt', icon: Settings, adminOnly: true },
          ].filter(item => !item.adminOnly || profile?.role === 'admin').map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold transition-all duration-200 ${
                activeTab === item.id 
                ? 'bg-[#0F172A] text-white shadow-lg shadow-slate-900/20' 
                : 'text-[#64748B] hover:bg-slate-50 hover:text-[#0F172A]'
              }`}
            >
              <item.icon size={20} className={activeTab === item.id ? 'text-white' : 'text-[#64748B]'} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-slate-50">
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center">SmartSales AI v2.5</p>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 ml-72 flex flex-col min-h-screen">
        {/* Top Header */}
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-10 px-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              {activeTab === 'dashboard' && 'Bảng điều khiển'}
              {activeTab === 'inventory' && 'Quản lý Kho hàng'}
              {activeTab === 'quotations' && 'Danh mục sản phẩm'}
              {activeTab === 'customers' && 'Quản lý Khách hàng'}
              {activeTab === 'reminders' && 'Bảo hành & Nhắc lịch'}
              {activeTab === 'pos' && 'Điểm bán hàng (POS)'}
              {activeTab === 'orders' && 'Lịch sử Đơn hàng'}
              {activeTab === 'reports' && 'Báo cáo Thống kê'}
              {activeTab === 'vat' && 'Báo cáo Thuế VAT'}
              {activeTab === 'staff' && 'Quản lý Nhân viên'}
              {activeTab === 'settings' && 'Cài đặt Hệ thống'}
            </h1>
          </div>

          <div className="flex items-center gap-6">
            {/* AI Assistant Trigger */}
            <button 
              onClick={() => setIsAiPanelOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/20 group"
            >
              <Sparkles size={18} className="text-yellow-400 group-hover:scale-110 transition-transform" />
              <span>Trợ lý AI</span>
            </button>

            <div className="h-8 w-px bg-slate-100"></div>

            {/* User Profile */}
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-900 leading-none mb-1">{profile?.displayName || 'Phạm Hoàng Hải'}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{profile?.role === 'admin' ? 'Quản trị viên' : 'Nhân viên'}</p>
              </div>
              <div className="relative group">
                <button className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center hover:ring-2 hover:ring-slate-900 transition-all">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  ) : (
                    <UserIcon size={20} className="text-slate-400" />
                  )}
                </button>
                
                {/* Profile Dropdown */}
                <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all translate-y-2 group-hover:translate-y-0">
                  <div className="px-3 py-2 border-b border-slate-50 mb-1">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Tài khoản</p>
                    <p className="text-xs text-slate-600 truncate">{user.email}</p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('settings')}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all"
                  >
                    <Settings size={16} />
                    <span>Cài đặt</span>
                  </button>
                  <button 
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-semibold text-red-600 hover:bg-red-50 transition-all"
                  >
                    <LogOut size={16} />
                    <span>Đăng xuất</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="p-8">
          <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <header className="flex justify-between items-end">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Chào buổi sáng, {profile?.displayName?.split(' ')[0]}!</h2>
                  <p className="text-slate-500">Đây là những gì đang diễn ra tại cửa hàng của bạn hôm nay.</p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <p className="text-sm font-semibold text-slate-500 uppercase tracking-widest">{format(new Date(), 'EEEE, dd MMMM')}</p>
                  <Button variant="secondary" size="sm" onClick={seedData} disabled={isAiLoading} icon={Plus} className="text-xs py-1.5">
                    Nạp dữ liệu mẫu (30/20)
                  </Button>
                </div>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="border-l-4 border-l-emerald-500">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Doanh thu hôm nay</p>
                  <h3 className="text-3xl font-bold text-slate-900">{stats.revenue.toLocaleString()}đ</h3>
                  <p className="text-sm text-emerald-600 mt-2 font-medium">+{stats.count} đơn hàng mới</p>
                </Card>
                <Card className="border-l-4 border-l-amber-500">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Sắp hết hàng</p>
                  <h3 className="text-3xl font-bold text-slate-900">{stats.lowStock} sản phẩm</h3>
                  <p className="text-sm text-amber-600 mt-2 font-medium">Cần nhập thêm ngay</p>
                </Card>
                <Card className="border-l-4 border-l-slate-900">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Tổng sản phẩm</p>
                  <h3 className="text-3xl font-bold text-slate-900">{products.length}</h3>
                  <p className="text-sm text-slate-500 mt-2 font-medium">Đang kinh doanh</p>
                </Card>
              </div>

              {stats.criticalLaptops.length > 0 && (
                <div className="bg-red-50 border border-red-100 p-4 rounded-2xl flex items-center gap-4 animate-pulse">
                  <div className="w-12 h-12 bg-red-100 text-red-600 rounded-xl flex items-center justify-center shrink-0">
                    <AlertCircle size={24} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-red-900">Cảnh báo tồn kho Laptop!</h4>
                    <p className="text-sm text-red-700">
                      Có {stats.criticalLaptops.length} dòng Laptop đang ở mức báo động (dưới 2 chiếc): {stats.criticalLaptops.map(p => p.name).join(', ')}
                    </p>
                  </div>
                  <Button variant="danger" onClick={() => setActiveTab('inventory')}>Nhập hàng ngay</Button>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-2">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-lg">Biểu đồ doanh thu</h3>
                    <select className="bg-slate-50 border-none text-sm font-medium rounded-lg px-3 py-1.5 outline-none">
                      <option>7 ngày qua</option>
                      <option>30 ngày qua</option>
                    </select>
                  </div>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={orders.slice(0, 7).reverse().map(s => ({ name: format(new Date(s.createdAt), 'dd/MM'), amount: s.totalAmount }))}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                          cursor={{ fill: '#f8fafc' }}
                        />
                        <Bar dataKey="amount" fill="#0f172a" radius={[4, 4, 0, 0]} barSize={40} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card className="bg-slate-900 text-white border-none shadow-xl shadow-slate-900/20">
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="text-emerald-400" size={20} />
                    <h3 className="font-bold text-lg">Trợ lý AI Gemini</h3>
                  </div>
                  <div className="space-y-4">
                    {isAiLoading ? (
                      <div className="flex flex-col items-center py-8 gap-3">
                        <div className="w-8 h-8 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                        <p className="text-slate-400 text-sm">Đang phân tích dữ liệu...</p>
                      </div>
                    ) : aiAdvice ? (
                      <div className="text-sm text-slate-300 prose prose-invert max-w-none">
                        <ReactMarkdown>{aiAdvice || ''}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="text-sm text-slate-400 italic">Nhấn nút bên dưới để nhận lời khuyên từ AI dựa trên dữ liệu bán hàng của bạn.</p>
                    )}
                    <Button 
                      variant="accent" 
                      className="w-full py-3 mt-4" 
                      onClick={fetchAiAdvice}
                      disabled={isAiLoading}
                    >
                      Phân tích ngay
                    </Button>
                  </div>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card>
                  <h3 className="font-bold text-lg mb-6">Hiệu suất nhân viên (Doanh số)</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        layout="vertical"
                        data={Object.entries(orders.reduce((acc: Record<string, number>, o) => {
                          acc[o.sellerName] = (acc[o.sellerName] || 0) + o.totalAmount;
                          return acc;
                        }, {})).map(([name, total]) => ({ name, total }))}
                      >
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={100} />
                        <Tooltip />
                        <Bar dataKey="total" fill="#10b981" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card>
                  <h3 className="font-bold text-lg mb-6">Top sản phẩm bán chạy</h3>
                  <div className="space-y-4">
                    {Object.entries(orders.flatMap(o => o.items).reduce((acc: Record<string, number>, item) => {
                      acc[item.name] = (acc[item.name] || 0) + item.quantity;
                      return acc;
                    }, {}))
                    .sort((a: any, b: any) => b[1] - a[1])
                    .slice(0, 5)
                    .map(([name, qty], idx) => (
                      <div key={name} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500">{idx + 1}</span>
                          <span className="font-medium text-slate-700">{name}</span>
                        </div>
                        <span className="font-bold text-slate-900">{qty} đã bán</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {activeTab === 'orders' && (
            <motion.div 
              key="orders"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Quản lý đơn hàng</h2>
                <div className="flex gap-2">
                  <Button variant="secondary" onClick={() => setActiveTab('pos')} icon={Plus}>Tạo đơn mới</Button>
                </div>
              </div>

              <Card className="overflow-hidden p-0">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-bottom border-slate-100">
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Mã đơn / Ngày</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Khách hàng</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Tổng tiền</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Thanh toán / Nợ</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Trạng thái</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(order => (
                      <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <p className="font-bold text-slate-900">#{order.id.slice(-6).toUpperCase()}</p>
                          <p className="text-xs text-slate-500">{format(new Date(order.createdAt), 'HH:mm dd/MM/yyyy')}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-bold text-slate-900">{order.customerName || 'Khách lẻ'}</p>
                          <p className="text-xs text-slate-500">{order.customerPhone}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-bold text-slate-900">{order.totalAmount.toLocaleString()}đ</p>
                          {order.shippingFee > 0 && <p className="text-xs text-slate-400">Ship: {order.shippingFee.toLocaleString()}đ</p>}
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm text-emerald-600 font-bold">Đã trả: {order.amountPaid.toLocaleString()}đ</p>
                          {order.debt > 0 && <p className="text-sm text-red-500 font-bold">Nợ: {order.debt.toLocaleString()}đ</p>}
                        </td>
                        <td className="px-6 py-4">
                          <select 
                            value={order.status}
                            onChange={(e) => updateOrderStatus(order.id, e.target.value as any)}
                            className={`text-xs font-bold px-2.5 py-1 rounded-full border-none focus:ring-0 cursor-pointer ${
                              order.status === OrderStatus.Completed ? 'bg-emerald-100 text-emerald-600' :
                              order.status === OrderStatus.Pending ? 'bg-amber-100 text-amber-600' :
                              'bg-red-100 text-red-600'
                            }`}
                          >
                            <option value="Pending">Chờ xử lý</option>
                            <option value="Completed">Hoàn thành</option>
                            <option value="Cancelled">Đã hủy</option>
                          </select>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="p-2 text-emerald-500 hover:bg-emerald-50" 
                              onClick={() => {
                                if (order.customerPhone) {
                                  const msg = getOrderNotificationMessage(order, 'delivery');
                                  sendZaloNotification(order.customerPhone, msg);
                                } else {
                                  notify('error', 'Khách hàng không có số điện thoại');
                                }
                              }}
                              title="Xác nhận giao hàng (Zalo)"
                            >
                              <Truck size={18} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="p-2 text-blue-500 hover:bg-blue-50" 
                              onClick={() => {
                                if (order.customerPhone) {
                                  const msg = getOrderNotificationMessage(order, 'status');
                                  sendZaloNotification(order.customerPhone, msg);
                                } else {
                                  notify('error', 'Khách hàng không có số điện thoại');
                                }
                              }}
                              title="Gửi Zalo"
                            >
                              <MessageSquare size={18} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              className="p-2 text-slate-500 hover:bg-slate-50" 
                              onClick={() => {
                                if (order.customerPhone) {
                                  const msg = getOrderNotificationMessage(order, 'status');
                                  sendSMSNotification(order.customerPhone, msg);
                                } else {
                                  notify('error', 'Khách hàng không có số điện thoại');
                                }
                              }}
                              title="Gửi SMS"
                            >
                              <Send size={18} />
                            </Button>
                            <Button variant="ghost" className="p-2 text-slate-400 hover:text-slate-900" onClick={() => handlePrint(order, false)}>
                              <Receipt size={18} />
                            </Button>
                            <Button variant="ghost" className="p-2 text-blue-500 hover:bg-blue-50" onClick={() => {
                              setSelectedOrder(order);
                              setIsOrderDetailsModalOpen(true);
                              setIsEditingOrder(false);
                            }}>
                              <Eye size={18} />
                            </Button>
                            <Button variant="ghost" className="p-2 text-amber-500 hover:bg-amber-50" onClick={() => {
                              setSelectedOrder(order);
                              setIsOrderDetailsModalOpen(true);
                              setIsEditingOrder(true);
                            }}>
                              <Edit2 size={18} />
                            </Button>
                            <Button variant="ghost" className="p-2 text-red-500 hover:bg-red-50" onClick={() => handleDeleteOrder(order.id)}>
                              <Trash2 size={18} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </motion.div>
          )}
          {activeTab === 'reminders' && (
            <motion.div 
              key="reminders"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">🛠️ Bảo hành & Nhắc lịch</h2>
                <Button variant="secondary" icon={Bell}>Cấu hình nhắc lịch</Button>
              </div>

              <div className="space-y-4">
                <h3 className="font-bold text-lg flex items-center gap-2">
                  <Bell className="text-amber-500" size={20} /> Lịch chăm sóc tự động
                </h3>
                
                {stats.reminders.length > 0 ? (
                  stats.reminders.map((order, idx) => (
                    <Card key={order.id} className={`border-l-4 ${idx % 2 === 0 ? 'border-l-red-500 bg-red-50/30' : 'border-l-amber-500 bg-amber-50/30'}`}>
                      <div className="flex justify-between items-start">
                        <div className="flex gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${idx % 2 === 0 ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'}`}>
                            {idx % 2 === 0 ? <Receipt size={24} /> : <Wrench size={24} />}
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900">Khách hàng: {order.customerName} - {order.customerPhone}</h4>
                            <p className="text-sm text-slate-600">
                              Sản phẩm: {order.items.map(i => i.name).join(', ')} (Mua {format(new Date(order.createdAt), 'dd/MM/yyyy')})
                            </p>
                            <p className={`text-sm font-bold mt-1 ${idx % 2 === 0 ? 'text-red-600' : 'text-amber-600'}`}>
                              {idx % 2 === 0 ? '⚠️ Cần nhắc thay mực / bảo trì máy in' : '📅 Cần nhắc vệ sinh máy / bảo dưỡng laptop'}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="secondary"
                            onClick={() => {
                              const msg = `Chào ${order.customerName}, Laptop Hoàng Hải nhắc bạn lịch bảo trì cho sản phẩm đã mua. Vui lòng liên hệ 0934.393.404 để đặt lịch. Trân trọng!`;
                              sendZaloNotification(order.customerPhone!, msg);
                            }}
                          >
                            Zalo
                          </Button>
                          <Button 
                            size="sm" 
                            variant="secondary"
                            onClick={() => {
                              const msg = `Chào ${order.customerName}, Laptop Hoàng Hải nhắc bạn lịch bảo trì cho sản phẩm đã mua. Trân trọng!`;
                              sendSMSNotification(order.customerPhone!, msg);
                            }}
                          >
                            SMS
                          </Button>
                          <Button size="sm" variant="secondary" onClick={() => window.location.href = `tel:${order.customerPhone}`}>Gọi ngay</Button>
                        </div>
                      </div>
                    </Card>
                  ))
                ) : (
                  <div className="space-y-4">
                    <Card className="border-l-4 border-l-red-500 bg-red-50/30">
                      <div className="flex justify-between items-start">
                        <div className="flex gap-4">
                          <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-red-100 text-red-600">
                            <Receipt size={24} />
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900">Khách hàng: Nguyễn Văn A - 0912xxx</h4>
                            <p className="text-sm text-slate-600">Máy in Canon 2900 (Mua 4 tháng trước)</p>
                            <p className="text-sm font-bold mt-1 text-red-600">⚠️ Cần nhắc thay mực</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="secondary" onClick={() => sendZaloNotification('0912345678', 'Chào bạn, Laptop Hoàng Hải nhắc bạn lịch thay mực máy in.')}>Zalo</Button>
                          <Button size="sm" variant="secondary" onClick={() => sendSMSNotification('0912345678', 'Chào bạn, Laptop Hoàng Hải nhắc bạn lịch thay mực máy in.')}>SMS</Button>
                          <Button size="sm" variant="secondary">Gọi ngay</Button>
                        </div>
                      </div>
                    </Card>
                    <Card className="border-l-4 border-l-amber-500 bg-amber-50/30">
                      <div className="flex justify-between items-start">
                        <div className="flex gap-4">
                          <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-amber-100 text-amber-600">
                            <Wrench size={24} />
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-900">Khách hàng: Trần Văn B - 0988xxx</h4>
                            <p className="text-sm text-slate-600">Laptop Dell 5490 (Mua 6 tháng trước)</p>
                            <p className="text-sm font-bold mt-1 text-amber-600">📅 Cần nhắc vệ sinh máy</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="secondary" onClick={() => sendZaloNotification('0988776655', 'Chào bạn, Laptop Hoàng Hải nhắc bạn lịch vệ sinh laptop.')}>Zalo</Button>
                          <Button size="sm" variant="secondary" onClick={() => sendSMSNotification('0988776655', 'Chào bạn, Laptop Hoàng Hải nhắc bạn lịch vệ sinh laptop.')}>SMS</Button>
                          <Button size="sm" variant="secondary">Gọi ngay</Button>
                        </div>
                      </div>
                    </Card>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === 'pos' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[calc(100vh-120px)]"
            >
              <div className="lg:col-span-2 flex flex-col gap-6 overflow-hidden">
                <div className="flex gap-4">
                  <div className="relative flex-1 product-suggestion-container">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                      placeholder="Tìm sản phẩm theo tên hoặc mã vạch..."
                      value={searchQuery}
                      onChange={(e) => handleProductSearch(e.target.value)}
                      onFocus={() => searchQuery.length >= 2 && setShowProductSuggestions(true)}
                      className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
                    />
                    
                    {showProductSuggestions && filteredProducts.length > 0 && (
                      <div className="absolute top-[calc(100%+8px)] left-0 right-0 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 max-h-96 overflow-y-auto">
                        {filteredProducts.map(p => (
                          <div 
                            key={p.id}
                            onClick={() => selectProduct(p)}
                            className="px-4 py-3 hover:bg-slate-50 cursor-pointer border-b border-slate-50 last:border-none flex justify-between items-center"
                          >
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-slate-900 truncate">{p.name}</p>
                              <p className="text-xs text-slate-500">{p.sku} • {p.sellPrice.toLocaleString()}đ</p>
                            </div>
                            <div className={`text-xs font-bold px-2 py-1 rounded-lg ${p.stock <= p.minStock ? 'bg-red-50 text-red-600' : 'bg-slate-50 text-slate-600'}`}>
                              {p.stock} {p.unit}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <select 
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="px-4 py-3 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:border-slate-900 transition-all"
                  >
                    <option value="Tất cả">Tất cả danh mục</option>
                    {Array.from(new Set(products.map(p => p.category))).map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                  <Button variant="secondary" onClick={() => setShowScanner(!showScanner)} icon={Scan}>
                    {showScanner ? 'Đóng Scanner' : 'Quét mã'}
                  </Button>
                </div>

                {showScanner && (
                  <Card className="relative">
                    <Scanner onScan={handleScan} />
                    <p className="text-center text-xs text-slate-500 mt-4">Đưa mã vạch vào khung hình để tự động thêm vào giỏ hàng</p>
                  </Card>
                )}

                <div className="flex-1 overflow-y-auto pr-2">
                  <table className="w-full text-left border-collapse">
                    <thead className="sticky top-0 bg-slate-50 z-10">
                      <tr className="border-b border-slate-200">
                        <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Sản phẩm</th>
                        <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Giá</th>
                        <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Kho</th>
                        <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {products
                        .filter(p => (selectedCategory === 'Tất cả' || p.category === selectedCategory) && 
                                    (p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                     p.sku.toLowerCase().includes(searchQuery.toLowerCase()) || 
                                     p.barcode?.includes(searchQuery)))
                        .map(product => (
                        <tr 
                          key={product.id}
                          onClick={() => addToCart(product)}
                          className="hover:bg-slate-50 cursor-pointer transition-colors group"
                        >
                          <td className="py-3 px-4">
                            <p className="font-bold text-slate-900">{product.name}</p>
                            <p className="text-xs text-slate-500">{product.sku}</p>
                          </td>
                          <td className="py-3 px-4 font-bold text-slate-900">
                            {product.sellPrice.toLocaleString()}đ
                          </td>
                          <td className="py-3 px-4">
                            <span className={`text-sm font-medium ${product.stock <= product.minStock ? 'text-red-500' : 'text-slate-600'}`}>
                              {product.stock} {product.unit}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center group-hover:bg-slate-900 group-hover:text-white transition-colors ml-auto">
                              <Plus size={16} />
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

                <Card className="flex flex-col h-full">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-xl">Giỏ hàng</h3>
                  <div className="flex gap-2">
                    <Button variant="ghost" className="p-2 text-emerald-600" onClick={fetchUpsellSuggestions} disabled={cart.length === 0 || isAiLoading} title="Gợi ý bán thêm">
                      <Sparkles size={20} />
                    </Button>
                    <span className="bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full text-xs font-bold">{cart.length} món</span>
                  </div>
                </div>

                {upsellSuggestions && (
                  <div className="mb-6 p-4 bg-emerald-50 border border-emerald-100 rounded-xl relative">
                    <button onClick={() => setUpsellSuggestions(null)} className="absolute top-2 right-2 text-emerald-400 hover:text-emerald-600">
                      <Plus className="rotate-45" size={16} />
                    </button>
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="text-emerald-500" size={16} />
                      <span className="text-xs font-bold text-emerald-700 uppercase">Gợi ý từ AI</span>
                    </div>
                    <div className="text-xs text-emerald-800 prose prose-sm max-w-none">
                      <ReactMarkdown>{upsellSuggestions || ''}</ReactMarkdown>
                    </div>
                  </div>
                )}

                <div className="space-y-4 mb-6">
                  <div className="grid grid-cols-2 gap-4 relative customer-suggestion-container">
                    <div className="relative group">
                      <Input 
                        label="Tên khách hàng" 
                        placeholder="Nguyễn Văn A" 
                        value={customerInfo.name}
                        onChange={(e: any) => handleCustomerInput('name', e.target.value)}
                        onFocus={() => customerInfo.name.length >= 2 && setShowCustomerSuggestions(true)}
                      />
                    </div>
                    <div className="relative group">
                      <Input 
                        label="Số điện thoại" 
                        placeholder="0901234567" 
                        value={customerInfo.phone}
                        onChange={(e: any) => handleCustomerInput('phone', e.target.value)}
                        onFocus={() => customerInfo.phone.length >= 2 && setShowCustomerSuggestions(true)}
                      />
                      {customerInfo.name && customerInfo.phone && (
                        <button 
                          onClick={() => handleQuickAddCustomer(customerInfo.name, customerInfo.phone)}
                          className="absolute right-2 top-8 p-1.5 bg-emerald-100 text-emerald-600 rounded-lg hover:bg-emerald-200 transition-colors"
                          title="Lưu nhanh khách hàng"
                        >
                          <UserPlus size={16} />
                        </button>
                      )}
                    </div>

                    {showCustomerSuggestions && filteredCustomers.length > 0 && (
                      <div className="absolute top-[calc(100%+4px)] left-0 right-0 bg-white border border-slate-200 rounded-xl shadow-xl z-50 max-h-60 overflow-y-auto">
                        {filteredCustomers.map(c => (
                          <div 
                            key={c.phone}
                            onClick={() => selectCustomer(c)}
                            className="px-4 py-3 hover:bg-slate-50 cursor-pointer border-b border-slate-50 last:border-none flex justify-between items-center"
                          >
                            <div>
                              <p className="font-bold text-slate-900">{c.name}</p>
                              <p className="text-xs text-slate-500">{c.phone}</p>
                            </div>
                            <div className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full uppercase">
                              Khách quen
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Hình thức thanh toán</label>
                      <select 
                        value={paymentType}
                        onChange={(e: any) => setPaymentType(e.target.value)}
                        className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-slate-900"
                      >
                        <option value="Full">Thanh toán đủ</option>
                        <option value="Installment">Trả góp</option>
                        <option value="Deposit">Đặt cọc</option>
                      </select>
                    </div>
                    <Input 
                      label="Phí vận chuyển" 
                      type="number"
                      placeholder="0" 
                      value={shippingFee}
                      onChange={(e: any) => setShippingFee(Number(e.target.value))}
                    />
                  </div>
                  <Input 
                    label="Địa chỉ giao hàng" 
                    placeholder="Số 123, Đường ABC..." 
                    value={shippingAddress}
                    onChange={(e: any) => setShippingAddress(e.target.value)}
                  />
                  <Input 
                    label="Ghi chú đơn hàng" 
                    placeholder="Giao giờ hành chính..." 
                    value={orderNote}
                    onChange={(e: any) => setOrderNote(e.target.value)}
                  />
                </div>

                <div className="flex-1 overflow-y-auto space-y-4 mb-6 pr-2">
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-4">
                      <ShoppingCart size={48} strokeWidth={1} />
                      <p className="text-sm">Giỏ hàng đang trống</p>
                    </div>
                  ) : (
                    cart.map(item => (
                      <div key={item.productId} className="flex gap-3 items-center">
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-slate-900 truncate">{item.name}</p>
                          <p className="text-sm text-slate-500">{(item.price * item.quantity).toLocaleString()}đ</p>
                        </div>
                        <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-1">
                          <button onClick={() => updateCartQuantity(item.productId, -1)} className="w-6 h-6 flex items-center justify-center hover:bg-white rounded transition-colors"><Minus size={14} /></button>
                          <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
                          <button onClick={() => updateCartQuantity(item.productId, 1)} className="w-6 h-6 flex items-center justify-center hover:bg-white rounded transition-colors"><Plus size={14} /></button>
                        </div>
                        <button onClick={() => removeFromCart(item.productId)} className="text-slate-300 hover:text-red-500 transition-colors"><Trash2 size={18} /></button>
                      </div>
                    ))
                  )}
                </div>

                <div className="space-y-4 pt-6 border-t border-slate-100">
                  <div className="flex justify-between items-center text-slate-500 text-sm">
                    <span>Tạm tính</span>
                    <span>{cart.reduce((sum, item) => sum + (item.price * item.quantity), 0).toLocaleString()}đ</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-500 text-sm">
                    <span>Thuế VAT</span>
                    <span>{cart.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0).toLocaleString()}đ</span>
                  </div>
                  <div className="flex justify-between items-center gap-4">
                    <span className="text-slate-500 text-sm">Giảm giá</span>
                    <input 
                      type="number" 
                      value={discount || ''}
                      onChange={(e) => setDiscount(e.target.value === '' ? 0 : Number(e.target.value))}
                      className="w-24 text-right bg-slate-50 border-none rounded p-1 text-sm font-bold"
                    />
                  </div>
                  <div className="flex justify-between items-center text-xl font-bold text-slate-900">
                    <span>Tổng cộng</span>
                    <span>{(cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + cart.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0) + shippingFee - discount).toLocaleString()}đ</span>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500 text-sm">Số tiền thanh toán</span>
                        <button 
                          onClick={() => {
                            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
                            const vatAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0);
                            setAmountPaid(subtotal + vatAmount + shippingFee - discount);
                          }}
                          className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded font-bold text-slate-600 transition-colors"
                        >
                          Trả đủ
                        </button>
                      </div>
                      <input 
                        type="number" 
                        value={amountPaid || ''}
                        onChange={(e) => setAmountPaid(e.target.value === '' ? 0 : Number(e.target.value))}
                        className="w-32 text-right bg-slate-50 border-none rounded p-1 text-sm font-bold"
                      />
                    </div>
                    <div className="flex justify-between items-center text-red-500 text-sm font-bold">
                      <span>Còn nợ</span>
                      <span>{Math.max(0, (cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + cart.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0) + shippingFee - discount) - amountPaid).toLocaleString()}đ</span>
                    </div>
                  </div>
                  <Button 
                    onClick={handleCheckout} 
                    className="w-full py-4 text-lg" 
                    disabled={cart.length === 0}
                  >
                    Thanh toán
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}

          {activeTab === 'quotations' && (
            <motion.div 
              key="quotations"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Quản lý Báo giá</h2>
                  <p className="text-slate-500">Tạo và gửi báo giá chuyên nghiệp cho khách hàng.</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="secondary" onClick={() => {
                    setQuotationItems([]);
                    setQuotationCustomer({ name: '', phone: '', email: '' });
                    setQuotationDiscount(0);
                    setQuotationNote('');
                    setAiSuggestions(null);
                    setCustomerNeeds('');
                  }} icon={Plus}>Tạo mới</Button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left: Form */}
                <div className="lg:col-span-2 space-y-6">
                  <Card className="space-y-6">
                    <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                      <UserIcon size={20} /> Thông tin khách hàng
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Họ tên</label>
                        <input 
                          type="text" 
                          placeholder="Nguyễn Văn A"
                          value={quotationCustomer.name}
                          onChange={(e) => setQuotationCustomer(prev => ({ ...prev, name: e.target.value }))}
                          className="w-full bg-slate-50 border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Số điện thoại</label>
                        <input 
                          type="text" 
                          placeholder="0912345678"
                          value={quotationCustomer.phone}
                          onChange={(e) => setQuotationCustomer(prev => ({ ...prev, phone: e.target.value }))}
                          className="w-full bg-slate-50 border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Email</label>
                        <input 
                          type="email" 
                          placeholder="email@example.com"
                          value={quotationCustomer.email}
                          onChange={(e) => setQuotationCustomer(prev => ({ ...prev, email: e.target.value }))}
                          className="w-full bg-slate-50 border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
                        />
                      </div>
                    </div>
                  </Card>

                  <Card className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                        <Package size={20} /> Danh sách sản phẩm
                      </h3>
                      <div className="relative w-64">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                        <input 
                          type="text" 
                          placeholder="Tìm sản phẩm..."
                          className="w-full bg-slate-50 border-none rounded-xl pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
                          onChange={(e) => {
                            const term = e.target.value.toLowerCase();
                            if (term.length > 2) {
                              const found = products.find(p => p.name.toLowerCase().includes(term) || p.sku.toLowerCase().includes(term));
                              if (found) addToQuotation(found);
                            }
                          }}
                        />
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="text-left border-b border-slate-100">
                            <th className="pb-4 font-bold text-slate-500 text-xs uppercase tracking-wider">Sản phẩm</th>
                            <th className="pb-4 font-bold text-slate-500 text-xs uppercase tracking-wider text-center">SL</th>
                            <th className="pb-4 font-bold text-slate-500 text-xs uppercase tracking-wider text-right">Đơn giá</th>
                            <th className="pb-4 font-bold text-slate-500 text-xs uppercase tracking-wider text-right">Thành tiền</th>
                            <th className="pb-4"></th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {quotationItems.map(item => (
                            <tr key={item.productId} className="group">
                              <td className="py-4">
                                <span className="font-bold text-slate-900">{item.name}</span>
                              </td>
                              <td className="py-4">
                                <div className="flex items-center justify-center gap-3">
                                  <button 
                                    onClick={() => setQuotationItems(prev => prev.map(i => i.productId === item.productId ? { ...i, quantity: Math.max(1, i.quantity - 1) } : i))}
                                    className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-900 transition-colors"
                                  >
                                    <Minus size={14} />
                                  </button>
                                  <span className="font-bold w-4 text-center">{item.quantity}</span>
                                  <button 
                                    onClick={() => setQuotationItems(prev => prev.map(i => i.productId === item.productId ? { ...i, quantity: i.quantity + 1 } : i))}
                                    className="p-1 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-900 transition-colors"
                                  >
                                    <Plus size={14} />
                                  </button>
                                </div>
                              </td>
                              <td className="py-4 text-right font-bold text-slate-900">
                                {item.price.toLocaleString()}đ
                              </td>
                              <td className="py-4 text-right font-bold text-slate-900">
                                {(item.price * item.quantity).toLocaleString()}đ
                              </td>
                              <td className="py-4 text-right">
                                <button 
                                  onClick={() => setQuotationItems(prev => prev.filter(i => i.productId !== item.productId))}
                                  className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </td>
                            </tr>
                          ))}
                          {quotationItems.length === 0 && (
                            <tr>
                              <td colSpan={5} className="py-12 text-center text-slate-400 italic">
                                Chưa có sản phẩm nào trong báo giá.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Ghi chú báo giá</label>
                      <textarea 
                        rows={3}
                        placeholder="VD: Báo giá có hiệu lực trong 7 ngày..."
                        value={quotationNote}
                        onChange={(e) => setQuotationNote(e.target.value)}
                        className="w-full bg-slate-50 border-none rounded-xl p-3 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
                      />
                    </div>
                  </Card>

                  {/* AI Suggestions Section */}
                  <Card className="bg-slate-900 text-white space-y-6 border-none shadow-2xl shadow-slate-900/20">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-bold flex items-center gap-2">
                        <Sparkles className="text-yellow-400" size={24} /> Trợ lý AI tư vấn sản phẩm
                      </h3>
                    </div>
                    <div className="space-y-4">
                      <p className="text-slate-400 text-sm">Nhập nhu cầu của khách hàng để AI gợi ý các sản phẩm phù hợp nhất từ kho hàng.</p>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="VD: Khách cần laptop văn phòng mỏng nhẹ, pin trâu, tầm giá 15-20tr..."
                          value={customerNeeds}
                          onChange={(e) => setCustomerNeeds(e.target.value)}
                          className="flex-1 bg-white/10 border-none rounded-xl p-3 text-sm text-white placeholder:text-slate-500 focus:ring-2 focus:ring-white/20 transition-all"
                        />
                        <Button 
                          onClick={handleAiSuggestQuotation} 
                          disabled={isAiSuggesting}
                          className="bg-white text-slate-900 hover:bg-slate-100"
                        >
                          {isAiSuggesting ? 'Đang phân tích...' : 'Gợi ý ngay'}
                        </Button>
                      </div>
                      
                      <AnimatePresence>
                        {aiSuggestions && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="bg-white/5 rounded-xl p-4 border border-white/10"
                          >
                            <div className="prose prose-invert prose-sm max-w-none">
                              <ReactMarkdown>{aiSuggestions}</ReactMarkdown>
                            </div>
                            <div className="mt-4 pt-4 border-t border-white/10 flex justify-end">
                              <Button variant="secondary" size="sm" onClick={() => setAiSuggestions(null)}>Đóng gợi ý</Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </Card>
                </div>

                {/* Right: Summary & Actions */}
                <div className="space-y-6">
                  <Card className="sticky top-24">
                    <h3 className="text-xl font-bold text-slate-900 mb-6">Tổng kết báo giá</h3>
                    <div className="space-y-4">
                      <div className="flex justify-between text-slate-500">
                        <span>Tạm tính</span>
                        <span className="font-bold text-slate-900">
                          {quotationItems.reduce((sum, item) => sum + (item.price * item.quantity), 0).toLocaleString()}đ
                        </span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Thuế VAT</span>
                        <span className="font-bold text-slate-900">
                          {quotationItems.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0).toLocaleString()}đ
                        </span>
                      </div>
                      <div className="flex justify-between items-center text-slate-500">
                        <span>Chiết khấu</span>
                        <input 
                          type="number" 
                          value={quotationDiscount || ''}
                          onChange={(e) => setQuotationDiscount(Number(e.target.value))}
                          className="w-24 text-right bg-slate-50 border-none rounded p-1 text-sm font-bold text-slate-900"
                        />
                      </div>
                      <div className="h-px bg-slate-100 my-4"></div>
                      <div className="flex justify-between items-center text-2xl font-bold text-slate-900">
                        <span>Tổng tiền</span>
                        <span>
                          {(
                            quotationItems.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 
                            quotationItems.reduce((sum, item) => sum + (item.price * item.quantity * (item.taxRate / 100)), 0) - 
                            quotationDiscount
                          ).toLocaleString()}đ
                        </span>
                      </div>

                      <div className="grid grid-cols-1 gap-3 pt-6">
                        <Button onClick={() => handleSaveQuotation('Draft')} variant="secondary" className="w-full py-3">
                          Lưu bản nháp
                        </Button>
                        <Button onClick={() => handleSendQuotation('message')} className="w-full py-3 bg-blue-600 hover:bg-blue-700" icon={MessageSquare}>
                          Gửi qua Zalo/Tin nhắn
                        </Button>
                        <Button onClick={() => handleSendQuotation('email')} className="w-full py-3 bg-slate-900" icon={Send}>
                          Gửi qua Email
                        </Button>
                      </div>
                    </div>
                  </Card>

                  <Card>
                    <h3 className="font-bold text-slate-900 mb-4">Báo giá gần đây</h3>
                    <div className="space-y-3">
                      {quotations.slice(0, 5).map(q => (
                        <div key={q.id} className="p-3 bg-slate-50 rounded-xl flex justify-between items-center group hover:bg-white hover:shadow-md transition-all cursor-pointer">
                          <div>
                            <p className="font-bold text-sm text-slate-900">{q.customerName}</p>
                            <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">{format(new Date(q.createdAt), 'dd/MM/yyyy HH:mm')}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-sm text-slate-900">{q.totalAmount.toLocaleString()}đ</p>
                            <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                              q.status === 'Draft' ? 'bg-slate-200 text-slate-600' : 
                              q.status === 'Sent' ? 'bg-blue-100 text-blue-600' : 
                              'bg-green-100 text-green-600'
                            }`}>
                              {q.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'categories' && (
            <motion.div 
              key="categories"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Danh mục sản phẩm</h2>
                <Button icon={Plus}>Thêm danh mục</Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categories.map(cat => (
                  <Card key={cat} className="hover:border-slate-900 transition-all cursor-pointer group">
                    <div className="flex justify-between items-start mb-4">
                      <div className="p-3 bg-slate-100 rounded-xl group-hover:bg-slate-900 group-hover:text-white transition-colors">
                        <Filter size={24} />
                      </div>
                      <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-full text-xs font-bold">
                        {products.filter(p => p.category === cat).length} sản phẩm
                      </span>
                    </div>
                    <h3 className="font-bold text-lg text-slate-900">{cat}</h3>
                    <p className="text-sm text-slate-500 mt-1">Quản lý các sản phẩm thuộc nhóm {cat}</p>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}
          {activeTab === 'settings' && (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Cài đặt Hệ thống</h2>
                  <p className="text-slate-500">Quản lý thông tin cửa hàng và cấu hình hệ thống.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-6">
                  <Card className="space-y-6">
                    <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                      <ShieldCheck size={20} /> Thông tin cửa hàng
                    </h3>
                    <div className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Tên cửa hàng</label>
                        <input 
                          type="text" 
                          value={storeSettings.name}
                          onChange={(e) => setStoreSettings(prev => ({ ...prev, name: e.target.value }))}
                          className="w-full bg-slate-50 border-none rounded-xl p-4 text-sm focus:ring-2 focus:ring-slate-900 transition-all font-bold"
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Số điện thoại</label>
                          <input 
                            type="text" 
                            value={storeSettings.phone}
                            onChange={(e) => setStoreSettings(prev => ({ ...prev, phone: e.target.value }))}
                            className="w-full bg-slate-50 border-none rounded-xl p-4 text-sm focus:ring-2 focus:ring-slate-900 transition-all font-bold"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Địa chỉ</label>
                          <input 
                            type="text" 
                            value={storeSettings.address}
                            onChange={(e) => setStoreSettings(prev => ({ ...prev, address: e.target.value }))}
                            className="w-full bg-slate-50 border-none rounded-xl p-4 text-sm focus:ring-2 focus:ring-slate-900 transition-all font-bold"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="pt-4 border-t border-slate-50">
                      <Button 
                        onClick={async () => {
                          try {
                            await setDoc(doc(db, 'settings', 'store'), storeSettings);
                            notify('success', 'Đã lưu cài đặt cửa hàng');
                          } catch (err) {
                            notify('error', 'Lỗi khi lưu cài đặt');
                          }
                        }}
                        className="px-8"
                      >
                        Lưu thay đổi
                      </Button>
                    </div>
                  </Card>

                  <Card className="space-y-6">
                    <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                      <Settings size={20} /> Cấu hình khác
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                        <div>
                          <p className="font-bold text-slate-900">Thông báo hệ thống</p>
                          <p className="text-xs text-slate-500">Nhận thông báo khi kho hàng sắp hết</p>
                        </div>
                        <div className="w-12 h-6 bg-emerald-500 rounded-full relative">
                          <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                        <div>
                          <p className="font-bold text-slate-900">Sao lưu tự động</p>
                          <p className="text-xs text-slate-500">Sao lưu dữ liệu hàng ngày lên Cloud</p>
                        </div>
                        <div className="w-12 h-6 bg-slate-200 rounded-full relative">
                          <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                        </div>
                      </div>
                    </div>
                  </Card>
                </div>

                <div className="space-y-6">
                  <Card className="text-center space-y-4">
                    <div className="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center mx-auto text-slate-400">
                      <ShieldCheck size={40} />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Bản quyền hệ thống</h4>
                      <p className="text-xs text-slate-500">SmartSales AI v2.5.0</p>
                    </div>
                    <p className="text-[10px] text-slate-400">Hệ thống được bảo mật và vận hành bởi Hoàng Hải Empire.</p>
                  </Card>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'inventory' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">📦 Tra cứu nhanh giá & Tồn kho</h2>
                <div className="flex gap-2">
                  <input
                    type="file"
                    id="excel-upload"
                    className="hidden"
                    accept=".xlsx, .xls"
                    onChange={handleExcelImport}
                  />
                  <Button 
                    variant="secondary" 
                    icon={FileUp} 
                    onClick={() => document.getElementById('excel-upload')?.click()}
                    disabled={isAiLoading}
                  >
                    Nhập từ Excel
                  </Button>
                  <input
                    type="file"
                    id="image-upload"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageImport}
                  />
                  <Button 
                    variant="accent" 
                    icon={ImageIcon} 
                    onClick={() => document.getElementById('image-upload')?.click()}
                    disabled={isAiLoading}
                  >
                    Nhập từ Ảnh (AI)
                  </Button>
                  <Button 
                    variant="ghost" 
                    icon={FileText} 
                    onClick={downloadExcelTemplate}
                  >
                    Tải file mẫu
                  </Button>
                  <Button 
                    icon={Plus}
                    onClick={() => {
                      setEditingProduct(null);
                      setProductForm({
                        name: '',
                        sku: '',
                        barcode: '',
                        category: 'Laptop',
                        unit: 'Cái',
                        buyPrice: 0,
                        sellPrice: 0,
                        taxRate: 10,
                        stock: 0,
                        minStock: 5
                      });
                      setIsProductModalOpen(true);
                    }}
                  >
                    Thêm sản phẩm
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">Chọn nhóm hàng</label>
                  <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                    {['Tất cả', ...categories].map(cat => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                          selectedCategory === cat 
                          ? 'bg-slate-900 text-white shadow-lg shadow-slate-900/10' 
                          : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-900'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-bold text-slate-500 uppercase">🔍 Nhập tên mã (Ví dụ: 830 G5, 2900, 35A...)</label>
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input
                      type="text"
                      placeholder="Tìm kiếm sản phẩm..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
                    />
                  </div>
                </div>
              </div>

              {selectedCategory === 'Laptop' && (
                <div className="bg-blue-50 border border-blue-100 p-4 rounded-2xl text-sm text-blue-700">
                  <strong>Dữ liệu tiêu biểu:</strong> HP EliteBook 830 G7 (5.2tr), Dell 5511 i7 (8tr)...
                </div>
              )}
              {selectedCategory === 'Hộp mực' && (
                <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl text-sm text-emerald-700">
                  <strong>Sẵn kho:</strong> TP-ink Q2612A (90k), 35A/85A (90k)...
                </div>
              )}

              <Card className="overflow-hidden p-0">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-bottom border-slate-100">
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Sản phẩm</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">SKU / Barcode</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Giá bán (VAT)</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Tồn kho</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Trạng thái</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {products
                      .filter(p => selectedCategory === 'Tất cả' || p.category === selectedCategory)
                      .filter(p => {
                        const query = searchQuery.toLowerCase();
                        return (
                          (p.name?.toLowerCase() || '').includes(query) || 
                          (p.barcode || '').includes(query) || 
                          (p.sku || '').includes(query)
                        );
                      })
                      .map(product => (
                        <tr key={product.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center overflow-hidden">
                              {product.imageUrl ? <img src={product.imageUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <Package size={20} className="text-slate-300" />}
                            </div>
                            <div>
                              <p className="font-bold text-slate-900">{product.name}</p>
                              <p className="text-xs text-slate-500">{product.category}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm font-bold text-slate-900">{product.sku}</p>
                          <p className="text-xs text-slate-500 font-mono">{product.barcode}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="font-bold text-slate-900">{product.sellPrice.toLocaleString()}đ</p>
                          <p className="text-xs text-emerald-600">Thuế: {product.taxRate}%</p>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`font-bold ${product.stock <= product.minStock ? 'text-red-500' : 'text-slate-900'}`}>
                            {product.stock}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {product.stock <= product.minStock ? (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-600">Sắp hết</span>
                          ) : (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-600">Sẵn sàng</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="p-2"
                              onClick={() => {
                                setEditingProduct(product);
                                setProductForm(product);
                                setIsProductModalOpen(true);
                              }}
                            >
                              <Edit2 size={18} />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="p-2 text-rose-500"
                              onClick={() => handleDeleteProduct(product.id)}
                            >
                              <Trash2 size={18} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </motion.div>
          )}

          {activeTab === 'customers' && (
            <motion.div 
              key="customers"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">🤝 Quản lý khách hàng thân thiết</h2>
                <div className="flex gap-3">
                  <Button variant="secondary" onClick={() => {
                    setEditingCustomer(null);
                    setCustomerForm({ name: '', phone: '', email: '', address: '', note: '' });
                    setIsCustomerModalOpen(true);
                  }} icon={Plus}>
                    Thêm khách hàng
                  </Button>
                  <Button variant="accent" onClick={fetchCustomerAnalysis} disabled={isAiLoading} icon={Sparkles}>
                    Phân tích RFM bằng AI
                  </Button>
                </div>
              </div>

              <Card className="bg-slate-50 border-dashed border-2 border-slate-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold flex items-center gap-2">
                    <Zap size={20} className="text-yellow-500" /> Thêm nhanh khách hàng
                  </h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                  <Input 
                    label="Tên khách" 
                    placeholder="Nhập tên..." 
                    value={customerForm.name}
                    onChange={(e: any) => setCustomerForm(prev => ({ ...prev, name: e.target.value }))}
                  />
                  <Input 
                    label="Số điện thoại" 
                    placeholder="09xxx..." 
                    value={customerForm.phone}
                    onChange={(e: any) => setCustomerForm(prev => ({ ...prev, phone: e.target.value }))}
                  />
                  <Button onClick={() => handleQuickAddCustomer(customerForm.name, customerForm.phone)} icon={Plus}>
                    Lưu nhanh
                  </Button>
                </div>
              </Card>

              {customerAnalysis && (
                <Card className="bg-slate-900 text-white border-none shadow-xl">
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="text-emerald-400" size={20} />
                    <h3 className="font-bold text-lg">Phân tích khách hàng AI</h3>
                  </div>
                  <div className="text-sm text-slate-300 prose prose-invert max-w-none">
                    <ReactMarkdown>{customerAnalysis || ''}</ReactMarkdown>
                  </div>
                </Card>
              )}

              <Card className="overflow-hidden p-0">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-bottom border-slate-100">
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Khách hàng</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Số điện thoại</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Số đơn đã mua</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Phân loại RFM</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Cập nhật</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {customers.map(customer => (
                      <tr key={customer.phone} className="hover:bg-slate-50/50 transition-colors group">
                        <td className="px-6 py-4">
                          <p className="font-bold text-slate-900">{customer.name}</p>
                          {customer.email && <p className="text-xs text-slate-500">{customer.email}</p>}
                        </td>
                        <td className="px-6 py-4 text-slate-500">{customer.phone}</td>
                        <td className="px-6 py-4 font-bold">{customer.purchaseHistory?.length || 0}</td>
                        <td className="px-6 py-4">
                          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
                            {customer.rfmScore || 'Khách mới'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-xs text-slate-400">{format(new Date(customer.updatedAt), 'dd/MM/yyyy')}</td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={() => {
                                setEditingCustomer(customer);
                                setCustomerForm({
                                  name: customer.name,
                                  phone: customer.phone,
                                  email: customer.email || '',
                                  address: customer.address || '',
                                  note: customer.note || ''
                                });
                                setIsCustomerModalOpen(true);
                              }}
                              className="p-2 hover:bg-emerald-50 text-emerald-600 rounded-lg transition-colors"
                            >
                              <Settings size={18} />
                            </button>
                            <button 
                              onClick={() => handleDeleteCustomer(customer.phone)}
                              className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors"
                            >
                              <Plus size={18} className="rotate-45" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div 
              key="reports"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Báo cáo & Phân tích</h2>
                <Button variant="secondary" onClick={exportToCSV} icon={Settings}>Xuất CSV cho Looker Studio</Button>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card>
                  <h3 className="font-bold text-lg mb-6">Lịch sử đơn hàng gần đây</h3>
                  <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                    {orders.map(order => (
                      <div key={order.id} className="group flex justify-between items-center p-4 hover:bg-slate-50 rounded-2xl transition-all border border-transparent hover:border-slate-200 hover:shadow-sm">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-bold text-slate-400">#{order.id.slice(-6).toUpperCase()}</span>
                            <p className="font-bold text-slate-900">{order.customerName || 'Khách lẻ'}</p>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-slate-500">
                            <span className="flex items-center gap-1"><Package size={12} /> {order.items.length} SP</span>
                            <span className="flex items-center gap-1"><BarChart3 size={12} /> {format(new Date(order.createdAt), 'HH:mm - dd/MM/yyyy')}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right mr-2">
                            <p className="font-bold text-slate-900">{order.finalAmount.toLocaleString()}đ</p>
                            <span className={`text-[10px] font-black uppercase tracking-tighter px-2 py-0.5 rounded-full ${
                              order.status === OrderStatus.Completed ? 'bg-emerald-100 text-emerald-600' :
                              order.status === OrderStatus.Pending ? 'bg-amber-100 text-amber-600' :
                              'bg-red-100 text-red-600'
                            }`}>
                              {order.status}
                            </span>
                          </div>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={() => {
                                setSelectedOrder(order);
                                setIsOrderDetailsModalOpen(true);
                                setIsEditingOrder(false);
                              }}
                              className="p-2 hover:bg-white rounded-lg text-slate-400 hover:text-blue-600 shadow-sm border border-transparent hover:border-slate-100 transition-all"
                              title="Xem chi tiết"
                            >
                              <Eye size={16} />
                            </button>
                            <button 
                              onClick={() => {
                                setSelectedOrder(order);
                                setIsOrderDetailsModalOpen(true);
                                setIsEditingOrder(true);
                              }}
                              className="p-2 hover:bg-white rounded-lg text-slate-400 hover:text-amber-600 shadow-sm border border-transparent hover:border-slate-100 transition-all"
                              title="Sửa đơn hàng"
                            >
                              <Edit2 size={16} />
                            </button>
                            <button 
                              onClick={() => handlePrint(order, false)}
                              className="p-2 hover:bg-white rounded-lg text-slate-400 hover:text-emerald-600 shadow-sm border border-transparent hover:border-slate-100 transition-all"
                              title="In hóa đơn"
                            >
                              <Receipt size={16} />
                            </button>
                            <button 
                              onClick={() => handleDeleteOrder(order.id)}
                              className="p-2 hover:bg-white rounded-lg text-slate-400 hover:text-red-600 shadow-sm border border-transparent hover:border-slate-100 transition-all"
                              title="Xóa đơn hàng"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>

                <Card>
                  <h3 className="font-bold text-lg mb-6">Hiệu suất nhân viên (Doanh số)</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        layout="vertical"
                        data={Object.entries(orders.reduce((acc: Record<string, number>, o) => {
                          acc[o.sellerName] = (acc[o.sellerName] || 0) + o.totalAmount;
                          return acc;
                        }, {})).map(([name, total]) => ({ name, total }))}
                      >
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={100} tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="total" fill="#10b981" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              </div>
            </motion.div>
          )}

          {activeTab === 'vat' && (
            <motion.div 
              key="vat"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Báo cáo thuế VAT</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-emerald-50 border-emerald-100">
                  <p className="text-xs font-bold text-emerald-600 uppercase tracking-widest mb-1">Tổng thuế đầu ra</p>
                  <h3 className="text-3xl font-bold text-emerald-900">
                    {vatReports.filter(r => r.type === 'Output').reduce((sum, r) => sum + r.taxAmount, 0).toLocaleString()}đ
                  </h3>
                </Card>
                <Card className="bg-slate-50 border-slate-200">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Tổng thuế đầu vào</p>
                  <h3 className="text-3xl font-bold text-slate-900">
                    {vatReports.filter(r => r.type === 'Input').reduce((sum, r) => sum + r.taxAmount, 0).toLocaleString()}đ
                  </h3>
                </Card>
              </div>

              <Card className="overflow-hidden p-0">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-bottom border-slate-100">
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Ngày</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Loại</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Giá trị trước thuế</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Tiền thuế</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Mô tả</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {vatReports.map(report => (
                      <tr key={report.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4 text-sm text-slate-500">{format(new Date(report.createdAt), 'dd/MM/yyyy')}</td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 rounded-lg text-xs font-bold ${report.type === 'Output' ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-600'}`}>
                            {report.type === 'Output' ? 'Đầu ra' : 'Đầu vào'}
                          </span>
                        </td>
                        <td className="px-6 py-4 font-bold text-slate-900">{report.amount.toLocaleString()}đ</td>
                        <td className="px-6 py-4 font-bold text-emerald-600">{report.taxAmount.toLocaleString()}đ</td>
                        <td className="px-6 py-4 text-sm text-slate-500">{report.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </motion.div>
          )}

          {activeTab === 'staff' && profile?.role === 'admin' && (
            <motion.div 
              key="staff"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Quản lý nhân viên</h2>
                <Button 
                  variant="primary" 
                  onClick={() => notify('success', 'Yêu cầu nhân viên mới đăng nhập bằng Google, sau đó bạn có thể thay đổi quyền hạn của họ tại đây.')}
                  icon={Plus}
                >
                  Thêm nhân viên
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-slate-900 text-white">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Tổng nhân viên</p>
                  <h3 className="text-3xl font-bold">{staff.length}</h3>
                </Card>
                <Card>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Best Seller</p>
                  <h3 className="text-xl font-bold text-slate-900 truncate">
                    {Object.entries(orders.reduce((acc: Record<string, number>, o) => {
                      acc[o.sellerName] = (acc[o.sellerName] || 0) + o.totalAmount;
                      return acc;
                    }, {})).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A'}
                  </h3>
                </Card>
                <Card>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Doanh số trung bình/NV</p>
                  <h3 className="text-3xl font-bold text-slate-900">
                    {staff.length > 0 ? (orders.reduce((sum, o) => sum + o.totalAmount, 0) / staff.length).toLocaleString() : 0}đ
                  </h3>
                </Card>
              </div>

              <Card className="overflow-hidden p-0">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-bottom border-slate-100">
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Nhân viên</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Quyền hạn</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Số đơn hàng</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Tổng doanh số</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {staff.map(member => {
                      const memberOrders = orders.filter(o => o.sellerId === member.uid);
                      const totalSales = memberOrders.reduce((sum, o) => sum + o.totalAmount, 0);
                      
                      return (
                        <tr key={member.uid} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4">
                            <div>
                              <p className="font-bold text-slate-900">{member.displayName}</p>
                              <p className="text-xs text-slate-500">{member.email}</p>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <select 
                              value={member.role}
                              onChange={(e) => updateUserRole(member.uid, e.target.value as any)}
                              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-bold outline-none focus:border-slate-900 transition-all"
                              disabled={member.uid === user?.uid}
                            >
                              <option value="admin">Admin</option>
                              <option value="sales">Sales</option>
                            </select>
                          </td>
                          <td className="px-6 py-4 font-bold text-slate-900">{memberOrders.length}</td>
                          <td className="px-6 py-4 font-bold text-emerald-600">{totalSales.toLocaleString()}đ</td>
                          <td className="px-6 py-4">
                            <Button 
                              variant="ghost" 
                              className="text-red-500 hover:bg-red-50 p-2"
                              onClick={() => deleteUser(member.uid)}
                              disabled={member.uid === user?.uid}
                            >
                              <Trash2 size={18} />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>

      {/* Product Management Modal */}
      <AnimatePresence>
        {isProductModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h3 className="text-xl font-bold text-slate-900">
                  {editingProduct ? 'Chỉnh sửa sản phẩm' : 'Thêm sản phẩm mới'}
                </h3>
                <button onClick={() => setIsProductModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X size={24} />
                </button>
              </div>
              <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative">
                    <Input 
                      label="Tên sản phẩm" 
                      value={productForm.name} 
                      onChange={(e: any) => {
                        const val = e.target.value;
                        setProductForm({...productForm, name: val});
                        if (val.length >= 2) {
                          const filtered = products.filter(p => p.name.toLowerCase().includes(val.toLowerCase()));
                          setProductNameSuggestions(filtered);
                          setShowNameSuggestions(filtered.length > 0);
                        } else {
                          setShowNameSuggestions(false);
                        }
                      }}
                      placeholder="Ví dụ: HP EliteBook 830 G7"
                    />
                    <AnimatePresence>
                      {showNameSuggestions && (
                        <motion.div 
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="absolute z-[60] left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-48 overflow-y-auto"
                        >
                          {productNameSuggestions.map(p => (
                            <button 
                              key={p.id}
                              onClick={() => {
                                setEditingProduct(p);
                                setProductForm(p);
                                setShowNameSuggestions(false);
                              }}
                              className="w-full px-4 py-2 text-left hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-none"
                            >
                              <p className="text-sm font-bold text-slate-900">{p.name}</p>
                              <p className="text-[10px] text-slate-500">SKU: {p.sku} | Tồn: {p.stock}</p>
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <div className="relative">
                    <Input 
                      label="Mã SKU" 
                      value={productForm.sku} 
                      onChange={(e: any) => {
                        const val = e.target.value;
                        setProductForm({...productForm, sku: val});
                        if (val.length >= 2) {
                          const filtered = products.filter(p => p.sku.toLowerCase().includes(val.toLowerCase()));
                          setSkuSuggestions(filtered);
                          setShowSkuSuggestions(filtered.length > 0);
                        } else {
                          setShowSkuSuggestions(false);
                        }
                      }}
                      placeholder="Ví dụ: HP-830G7"
                    />
                    <AnimatePresence>
                      {showSkuSuggestions && (
                        <motion.div 
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="absolute z-[60] left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-xl max-h-48 overflow-y-auto"
                        >
                          {skuSuggestions.map(p => (
                            <button 
                              key={p.id}
                              onClick={() => {
                                setEditingProduct(p);
                                setProductForm(p);
                                setShowSkuSuggestions(false);
                              }}
                              className="w-full px-4 py-2 text-left hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-none"
                            >
                              <p className="text-sm font-bold text-slate-900">{p.name}</p>
                              <p className="text-[10px] text-slate-500">SKU: {p.sku} | Tồn: {p.stock}</p>
                            </button>
                          ))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Input 
                    label="Mã vạch (Barcode)" 
                    value={productForm.barcode} 
                    onChange={(e: any) => setProductForm({...productForm, barcode: e.target.value})}
                    placeholder="Quét hoặc nhập mã vạch"
                  />
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Danh mục</label>
                    <select 
                      value={productForm.category}
                      onChange={(e) => setProductForm({...productForm, category: e.target.value})}
                      className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
                    >
                      <option value="Laptop">Laptop</option>
                      <option value="Hộp mực">Hộp mực</option>
                      <option value="Linh kiện">Linh kiện</option>
                      <option value="Khác">Khác</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <Input 
                    label="Giá nhập" 
                    type="number"
                    value={productForm.buyPrice} 
                    onChange={(e: any) => setProductForm({...productForm, buyPrice: Number(e.target.value)})}
                  />
                  <Input 
                    label="Giá bán" 
                    type="number"
                    value={productForm.sellPrice} 
                    onChange={(e: any) => setProductForm({...productForm, sellPrice: Number(e.target.value)})}
                  />
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Thuế (%)</label>
                    <select 
                      value={productForm.taxRate}
                      onChange={(e) => setProductForm({...productForm, taxRate: Number(e.target.value) as any})}
                      className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all"
                    >
                      <option value={0}>0%</option>
                      <option value={5}>5%</option>
                      <option value={8}>8%</option>
                      <option value={10}>10%</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Input 
                    label="Tồn kho" 
                    type="number"
                    value={productForm.stock} 
                    onChange={(e: any) => setProductForm({...productForm, stock: Number(e.target.value)})}
                  />
                  <Input 
                    label="Tồn tối thiểu" 
                    type="number"
                    value={productForm.minStock} 
                    onChange={(e: any) => setProductForm({...productForm, minStock: Number(e.target.value)})}
                  />
                </div>
              </div>
              <div className="p-6 bg-slate-50 flex justify-end gap-3">
                <Button variant="ghost" onClick={() => setIsProductModalOpen(false)}>Hủy</Button>
                <Button onClick={handleSaveProduct} disabled={isAiLoading}>
                  {isAiLoading ? 'Đang lưu...' : 'Lưu sản phẩm'}
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Image Import Modal */}
      <AnimatePresence>
        {isImageImportModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">Kết quả phân tích từ AI</h3>
                  <p className="text-sm text-slate-500">Vui lòng kiểm tra lại thông tin trước khi lưu vào kho hàng.</p>
                </div>
                <Button variant="ghost" onClick={() => setIsImageImportModalOpen(false)}>
                  <Plus className="rotate-45" size={24} />
                </Button>
              </div>

              <div className="flex-1 overflow-y-auto p-6">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100">
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Sản phẩm</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Giá bán</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Tồn kho</th>
                      <th className="py-3 px-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Mô tả</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {extractedProducts.map((p, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-3 px-4">
                          <input 
                            value={p.name}
                            onChange={(e) => {
                              const newProducts = [...extractedProducts];
                              newProducts[idx].name = e.target.value;
                              setExtractedProducts(newProducts);
                            }}
                            className="w-full bg-transparent font-bold text-slate-900 outline-none focus:text-emerald-600"
                          />
                          <p className="text-xs text-slate-400">{p.sku || 'Tự động tạo SKU'}</p>
                        </td>
                        <td className="py-3 px-4">
                          <input 
                            type="number"
                            value={p.sellPrice}
                            onChange={(e) => {
                              const newProducts = [...extractedProducts];
                              newProducts[idx].sellPrice = Number(e.target.value);
                              setExtractedProducts(newProducts);
                            }}
                            className="w-full bg-transparent font-bold text-slate-900 outline-none focus:text-emerald-600"
                          />
                        </td>
                        <td className="py-3 px-4">
                          <input 
                            type="number"
                            value={p.stock || 1}
                            onChange={(e) => {
                              const newProducts = [...extractedProducts];
                              newProducts[idx].stock = Number(e.target.value);
                              setExtractedProducts(newProducts);
                            }}
                            className="w-20 bg-transparent font-bold text-slate-900 outline-none focus:text-emerald-600"
                          />
                        </td>
                        <td className="py-3 px-4">
                          <textarea 
                            value={p.description || ''}
                            onChange={(e) => {
                              const newProducts = [...extractedProducts];
                              newProducts[idx].description = e.target.value;
                              setExtractedProducts(newProducts);
                            }}
                            className="w-full bg-transparent text-xs text-slate-500 outline-none focus:text-emerald-600 resize-none"
                            rows={2}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="p-6 border-t border-slate-100 flex justify-end gap-3 bg-slate-50/50">
                <Button variant="secondary" onClick={() => setIsImageImportModalOpen(false)}>Hủy bỏ</Button>
                <Button variant="primary" onClick={saveExtractedProducts} disabled={isAiLoading}>
                  {isAiLoading ? 'Đang lưu...' : `Lưu ${extractedProducts.length} sản phẩm`}
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Order Success Modal */}
      <AnimatePresence>
        {showSuccessModal && lastOrder && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-8 text-center space-y-6">
                <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 size={40} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Thanh toán thành công!</h3>
                  <p className="text-slate-500">Đơn hàng #{lastOrder.id.slice(-6)} đã được ghi nhận.</p>
                </div>

                <div className="bg-slate-50 p-6 rounded-2xl space-y-4">
                  <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Quét mã VietQR để thanh toán</p>
                  <img 
                    src={generateVietQRUrl(lastOrder.finalAmount || lastOrder.totalAmount, `Thanh toan don hang ${lastOrder.id.slice(-6)}`)} 
                    alt="VietQR" 
                    className="mx-auto w-48 h-48 rounded-xl shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                  <p className="text-lg font-bold text-slate-900">{(lastOrder.finalAmount || lastOrder.totalAmount).toLocaleString()}đ</p>
                </div>

                <div className="grid grid-cols-4 gap-2">
                  <Button variant="secondary" className="w-full text-[10px] px-1" onClick={() => handlePrint(lastOrder, true)} icon={Receipt}>
                    PDF
                  </Button>
                  <Button variant="secondary" className="w-full text-[10px] px-1" onClick={() => handlePrint(lastOrder, false)} icon={FileText}>
                    Hoá đơn A4
                  </Button>
                  <Button variant="secondary" className="w-full text-[10px] px-1" onClick={() => handlePrint(lastOrder, true)} icon={Receipt}>
                    Máy in
                  </Button>
                  <Button variant="primary" className="w-full text-[10px] px-1" onClick={() => { setLastOrder(null); setShowSuccessModal(false); }}>
                    Tiếp tục
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Customer Modal */}
      <AnimatePresence>
        {isCustomerModalOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-slate-900">
                  {editingCustomer ? 'Cập nhật khách hàng' : 'Thêm khách hàng mới'}
                </h3>
                <button 
                  onClick={() => setIsCustomerModalOpen(false)}
                  className="p-2 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  <Plus size={24} className="rotate-45" />
                </button>
              </div>
              <form onSubmit={handleSaveCustomer} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input 
                    label="Tên khách hàng" 
                    required
                    value={customerForm.name}
                    onChange={(e: any) => setCustomerForm(prev => ({ ...prev, name: e.target.value }))}
                  />
                  <Input 
                    label="Số điện thoại" 
                    required
                    disabled={!!editingCustomer}
                    value={customerForm.phone}
                    onChange={(e: any) => setCustomerForm(prev => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <Input 
                  label="Email" 
                  type="email"
                  value={customerForm.email}
                  onChange={(e: any) => setCustomerForm(prev => ({ ...prev, email: e.target.value }))}
                />
                <Input 
                  label="Địa chỉ" 
                  value={customerForm.address}
                  onChange={(e: any) => setCustomerForm(prev => ({ ...prev, address: e.target.value }))}
                />
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ghi chú</label>
                  <textarea 
                    className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/5 focus:border-slate-900 transition-all min-h-[100px]"
                    value={customerForm.note}
                    onChange={(e: any) => setCustomerForm(prev => ({ ...prev, note: e.target.value }))}
                  />
                </div>
                <div className="pt-4 flex gap-3">
                  <Button variant="secondary" className="flex-1" onClick={() => setIsCustomerModalOpen(false)}>
                    Hủy
                  </Button>
                  <Button type="submit" className="flex-1">
                    {editingCustomer ? 'Cập nhật' : 'Lưu khách hàng'}
                  </Button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* AI Assistant Side Panel */}
      <AnimatePresence>
        {isAiPanelOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAiPanelOpen(false)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center">
                    <Sparkles className="text-yellow-400" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg leading-none">Trợ lý AI Hoàng Hải</h3>
                    <p className="text-[10px] text-slate-400 uppercase tracking-widest mt-1">Sẵn sàng hỗ trợ bạn 24/7</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsAiPanelOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <Plus size={24} className="rotate-45" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/50">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] p-4 rounded-2xl shadow-sm ${
                      msg.role === 'user' 
                      ? 'bg-slate-900 text-white rounded-tr-none' 
                      : 'bg-white text-slate-900 rounded-tl-none border border-slate-100'
                    }`}>
                      <div className="prose prose-sm prose-slate max-w-none">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                    </div>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm">
                      <div className="flex gap-1">
                        <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce"></div>
                        <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                        <div className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <div className="p-6 bg-white border-t border-slate-100">
                <div className="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
                  {[
                    'Kiểm tra kho Laptop HP',
                    'Khách hàng mua nhiều nhất',
                    'Lịch bảo hành sắp tới',
                    'Báo cáo doanh thu tháng'
                  ].map(suggestion => (
                    <button 
                      key={suggestion}
                      onClick={() => handleSendMessage(undefined, suggestion)}
                      className="whitespace-nowrap px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-lg text-[10px] font-bold transition-all border border-slate-100"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    id="ai-chat-input"
                    placeholder="Hỏi tôi bất cứ điều gì..."
                    className="flex-1 bg-slate-50 border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-slate-900 transition-all"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleSendMessage(undefined, e.currentTarget.value);
                        e.currentTarget.value = '';
                      }
                    }}
                  />
                  <button 
                    onClick={() => {
                      const input = document.getElementById('ai-chat-input') as HTMLInputElement;
                      if (input) {
                        handleSendMessage(undefined, input.value);
                        input.value = '';
                      }
                    }}
                    className="p-3 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/20"
                  >
                    <Send size={20} />
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Order Details Modal */}
      <AnimatePresence>
        {isOrderDetailsModalOpen && selectedOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setIsOrderDetailsModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                    {isEditingOrder ? 'Chỉnh sửa đơn hàng' : 'Chi tiết đơn hàng'}
                    <span className="text-slate-400 font-normal text-lg">#{selectedOrder.id.slice(-6)}</span>
                  </h2>
                  <p className="text-slate-500 text-sm">{format(new Date(selectedOrder.createdAt), 'dd/MM/yyyy HH:mm')}</p>
                </div>
                <button 
                  onClick={() => setIsOrderDetailsModalOpen(false)}
                  className="p-2 hover:bg-white rounded-xl transition-colors shadow-sm border border-slate-100"
                >
                  <X size={24} className="text-slate-400" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Left Column: Order Info */}
                  <div className="space-y-6">
                    <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Thông tin khách hàng</h3>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                            <UserIcon size={20} />
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{selectedOrder.customerName}</p>
                            <p className="text-sm text-slate-500">{selectedOrder.customerPhone || 'Không có số điện thoại'}</p>
                          </div>
                        </div>
                        {selectedOrder.shippingAddress && (
                          <div className="flex items-start gap-3 mt-4">
                            <MapPin size={18} className="text-slate-400 mt-0.5" />
                            <p className="text-sm text-slate-600 leading-relaxed">{selectedOrder.shippingAddress}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Trạng thái & Thanh toán</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-xs text-slate-400 mb-1">Phương thức</p>
                          <div className="flex items-center gap-2 font-bold text-slate-700">
                            {selectedOrder.paymentType}
                          </div>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400 mb-1">Trạng thái</p>
                          <select 
                            disabled={!isEditingOrder}
                            value={selectedOrder.status}
                            onChange={(e) => setSelectedOrder({...selectedOrder, status: e.target.value as any})}
                            className={`w-full px-3 py-1.5 rounded-lg text-sm font-bold border-none focus:ring-2 focus:ring-blue-500 ${
                              selectedOrder.status === OrderStatus.Completed ? 'bg-emerald-100 text-emerald-700' :
                              selectedOrder.status === OrderStatus.Pending ? 'bg-amber-100 text-amber-700' :
                              'bg-red-100 text-red-700'
                            }`}
                          >
                            <option value={OrderStatus.Pending}>Chờ xử lý</option>
                            <option value={OrderStatus.Completed}>Hoàn thành</option>
                            <option value={OrderStatus.Cancelled}>Đã hủy</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Items */}
                  <div className="space-y-6">
                    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
                      <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                        <h3 className="text-sm font-bold text-slate-900">Sản phẩm ({selectedOrder.items.length})</h3>
                      </div>
                      <div className="divide-y divide-slate-50 max-h-[300px] overflow-y-auto">
                        {selectedOrder.items.map((item, idx) => (
                          <div key={idx} className="p-4 flex justify-between items-center hover:bg-slate-50/50 transition-colors">
                            <div className="flex-1 min-w-0 mr-4">
                              <p className="font-bold text-slate-900 truncate">{item.name}</p>
                              <p className="text-xs text-slate-500">
                                {item.quantity} x {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(item.price)}
                              </p>
                            </div>
                            <p className="font-bold text-slate-900">
                              {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(item.price * item.quantity)}
                            </p>
                          </div>
                        ))}
                      </div>
                      <div className="p-6 bg-slate-900 text-white space-y-3">
                        <div className="flex justify-between text-slate-400 text-sm">
                          <span>Tạm tính</span>
                          <span>{new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(selectedOrder.subtotal)}</span>
                        </div>
                        <div className="flex justify-between text-slate-400 text-sm">
                          <span>Thuế (VAT)</span>
                          <span>{new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(selectedOrder.vatAmount)}</span>
                        </div>
                        <div className="flex justify-between items-center pt-2 border-t border-white/10">
                          <span className="font-bold">Tổng cộng</span>
                          <span className="text-2xl font-black text-blue-400">
                            {new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(selectedOrder.finalAmount)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    className="gap-2 border-slate-200"
                    onClick={() => handlePrint(selectedOrder, false)}
                  >
                    <Eye size={18} />
                    Xem hóa đơn
                  </Button>
                  <Button 
                    variant="outline" 
                    className="gap-2 border-slate-200"
                    onClick={() => handlePrint(selectedOrder, true)}
                  >
                    <Receipt size={18} />
                    In hóa đơn
                  </Button>
                  <Button 
                    variant="outline" 
                    className="gap-2 border-slate-200 text-blue-600 hover:bg-blue-50"
                    onClick={() => {
                      if (selectedOrder.customerPhone) {
                        const msg = getOrderNotificationMessage(selectedOrder, 'status');
                        sendZaloNotification(selectedOrder.customerPhone, msg);
                      } else {
                        notify('error', 'Khách hàng không có số điện thoại');
                      }
                    }}
                  >
                    <MessageSquare size={18} />
                    Gửi Zalo
                  </Button>
                </div>
                <div className="flex gap-3">
                  {isEditingOrder ? (
                    <>
                      <Button 
                        variant="ghost" 
                        onClick={() => setIsEditingOrder(false)}
                      >
                        Hủy
                      </Button>
                      <Button 
                        className="bg-blue-600 hover:bg-blue-700 text-white px-8"
                        onClick={() => handleUpdateOrder(selectedOrder)}
                      >
                        Lưu thay đổi
                      </Button>
                    </>
                  ) : (
                    <div className="flex gap-3">
                      <Button 
                        variant="outline" 
                        className="text-red-500 border-red-100 hover:bg-red-50"
                        onClick={() => handleDeleteOrder(selectedOrder.id)}
                      >
                        Xoá đơn hàng
                      </Button>
                      <Button 
                        className="bg-blue-600 hover:bg-blue-700 text-white px-8"
                        onClick={() => setIsEditingOrder(true)}
                      >
                        Chỉnh sửa
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Notifications */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-8 right-8 px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 z-50 ${
              notification.type === 'success' ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'
            }`}
          >
            {notification.type === 'success' ? <CheckCircle2 size={24} /> : <AlertCircle size={24} />}
            <p className="font-bold">{notification.message}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {showInvoice && currentOrder && (
        <Invoice 
          order={currentOrder} 
          onClose={() => {
            setShowInvoice(false);
            setAutoPrintInvoice(false);
          }} 
          autoPrint={autoPrintInvoice}
        />
      )}
    </div>
  );
}
