export type UserRole = 'admin' | 'sales';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  createdAt: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  barcode: string;
  category: string;
  unit: string;
  buyPrice: number;
  sellPrice: number;
  taxRate: 0 | 5 | 8 | 10;
  stock: number;
  minStock: number;
  imageUrl?: string;
  updatedAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
  taxRate: number;
}

export enum OrderStatus {
  Pending = 'Pending',
  Completed = 'Completed',
  Cancelled = 'Cancelled'
}

export enum PaymentType {
  Full = 'Full',
  Installment = 'Installment',
  Deposit = 'Deposit'
}

export interface Order {
  id: string;
  customerName?: string;
  customerPhone?: string;
  items: OrderItem[];
  subtotal: number;
  vatAmount: number;
  discount: number;
  shippingFee: number;
  totalAmount: number;
  finalAmount: number;
  amountPaid: number;
  debt: number;
  status: OrderStatus;
  paymentType: PaymentType;
  shippingAddress?: string;
  note?: string;
  sellerId: string;
  sellerName: string;
  createdAt: string;
}

export interface Customer {
  phone: string;
  name: string;
  email?: string;
  address?: string;
  note?: string;
  purchaseHistory: string[];
  rfmScore?: string;
  updatedAt: string;
}

export interface Quotation {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  items: OrderItem[];
  subtotal: number;
  vatAmount: number;
  discount: number;
  totalAmount: number;
  note?: string;
  status: 'Draft' | 'Sent' | 'Accepted' | 'Rejected';
  sellerId: string;
  sellerName: string;
  createdAt: string;
  updatedAt: string;
}

export interface VATReport {
  id: string;
  type: 'Input' | 'Output';
  amount: number;
  taxAmount: number;
  taxRate: number;
  referenceId?: string;
  description?: string;
  createdAt: string;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string;
    email?: string | null;
    emailVerified?: boolean;
    isAnonymous?: boolean;
    tenantId?: string | null;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}
