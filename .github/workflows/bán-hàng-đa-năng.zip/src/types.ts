export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  description?: string;
  warrantyMonths: number;
  price: number;
  createdAt: string;
}

export interface Warranty {
  id: string;
  serialNumber: string;
  productId: string;
  productName: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  activationDate: string;
  expiryDate: string;
  status: 'active' | 'expired' | 'voided';
  activatedBy: string;
}

export interface UserPermissions {
  canAddInvoice: boolean;
  canEditInvoice: boolean;
  canDeleteInvoice: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'staff';
  avatar?: string;
  phone?: string;
  address?: string;
  permissions?: UserPermissions;
  createdAt: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  items: OrderItem[];
  totalAmount: number;
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: string;
  createdBy: string;
  createdByEmail?: string;
  editHistory?: {
    timestamp: string;
    userId: string;
    userName: string;
    action: string;
  }[];
}
